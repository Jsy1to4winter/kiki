# 失真档案 · 给 Claude 的交接包

打包日期：2026-11-02（Asia/Shanghai）。源码基线：a17a757c5682dae2ac297800bdc68148f91035eb。

## 从哪里开始

当前正在制作、并由 GitHub Pages 发布的资料展示网页是：
`repository/public/personal-archive/`

请先阅读该目录的 `index.html`、`style.css`、`app.js`、`music.js` 和 `music-tracks.json`。
仓库根目录的 `index.html` / `src/` 是更早的 Three.js 作品集，与当前资料展示页不是同一入口；为保留完整项目上下文，一并打包，不要误改为当前页面入口。

在线页面：https://jsy1to4winter.github.io/kiki/
仓库：https://github.com/Jsy1to4winter/kiki
部署流程：https://github.com/Jsy1to4winter/kiki/actions/workflows/personal-archive-pages.yml

## 包含内容

- repository/：完整的已跟踪仓库文件，保留目录结构，包括当前网页的全部图片、SVG、两首音乐、歌词、原有源码与工具资料。
- repository/.github/workflows/personal-archive-pages.yml：当前 GitHub Pages 配置，将 `public/personal-archive` 直接发布为站点根目录。
- reference-uploads/：本会话可读取的原始 Word 文档、歌词效果参考视频、用户最后提供的初版交接 ZIP。
- reference-uploads/假贵族-歌词.txt：用户在聊天中提供的歌词整理版。
- FILES.sha256：压缩包内文件的 SHA-256 校验清单。

不包含 `.git`、`node_modules`、构建缓存或执行环境配置。图片内嵌在聊天里且没有原文件的参考图无法全部还原；网页实际使用的已处理图片均完整保留在 assets/ 中。不要把参考效果中的真人图片当成自介素材。

## 当前网页结构

- index.html：封面、五个栏目、常驻音乐与歌词区域、详情弹窗。
- style.css：响应式布局、教堂背景、磨砂卡片、人物边缘渐隐、资料排版、抽象线条装饰。
- app.js：栏目切换、左右滑动、随笔与图片详情；切页同步替换，不叠加模糊动画。
- music.js：单个 audio 实例，两首歌曲循环，首次展开、再次点击切歌并收回，暂停和媒体会话支持。
- music-tracks.json：歌曲信息、音频路径及歌词；歌词独立于栏目，不随切页重置。
- assets/cathedral-background.png：轻微模糊的教堂背景素材。
- assets/profile-portrait.png：用户星形帽子插画处理后的透明边缘素材。
- assets/close-detail.svg、music-note-sparkle.svg：用户提供 SVG 的页面实现。

## 本地查看和构建

当前资料页是纯静态 HTML/CSS/JS，无后端、无必需密钥。

保留仓库开发方式（Node.js 24.19.0 / npm 11.9.0 已验证；README 要求 Node.js 22.12+）：

```sh
cd repository
npm ci
npm run dev -- --port 5174 --strictPort
```

在本机打开开发服务的 `/personal-archive/` 路径。`npm run build` 会把该页连同素材复制到 `dist/personal-archive/`。

也可直接启动静态 HTTP 服务指向 `repository/public/personal-archive/`。不要只双击 index.html：音乐模块会通过 fetch 读取 JSON，file 协议可能被浏览器限制。

## 当前状态及边界

- 已验证 320、390、650、1280 像素宽度，五页导航、随笔弹窗、图片查看、返回首页和构建。
- 已用实际音频检查播放、暂停、切歌、歌曲结束循环、跨栏目持续播放。
- 手机浏览器不保证有声自动播放；已尝试自动播放，遭拦截时在首次点击封面后启动。不要声称能绕过浏览器策略。
- 《假贵族》有用户提供的 68 行歌词，没有逐句时间戳，当前按音频时长均匀轮播，并非精确 LRC 同步。《Thelema》未提供歌词。
- 姓名、年龄、技能、标签、拟化物仍是待填写字段。评价、介绍与随笔部分内容是明示的排版占位，不代表真实经历或成绩。
- 用浏览器模拟检查过手机布局及触控；不等于 iPhone 真机全面验证。

## 用户已表达的设计偏好（交接参考）

- 灰白、教堂光影、透明磨砂；辅助点缀使用金色，不加入突兀的写实装饰。
- 底部导航在电脑和手机均保持小巧，目前约 240×48 CSS 像素；用户会在电脑上拖窄浏览器窗口查看手机布局。
- 主卡片的磨砂需要比背景更清楚，但仍能透出教堂轮廓。
- 自介图使用当前用户插画，主体清晰，周边柔和渐隐；旧参考图只参考边缘融合效果。
- 资料区使用编号、竖向索引和文字层级；其他四页用低对比的抽象轨道、曲线、圆环等线稿填充。
- 保持切页背景稳定，避免两层透明面板叠加、残留选中圆圈和手机双击误放大；保留用户主动双指缩放。
- 不添加编辑页面或编辑按钮；不编造个人信息、评价和运营成绩。
- 每次修改完成后，提供新版网页链接，并在下一行提供该次 GitHub Actions 部署状态链接；只在核实成功后标注已成功。

## 接续工作提醒

本包是源码与素材快照，不包含聊天中每张参考图的原始文件。需要具体姓名等信息或精确歌词同步时，应向用户获取内容或时间戳。对网页的修改以用户新的指令为准。

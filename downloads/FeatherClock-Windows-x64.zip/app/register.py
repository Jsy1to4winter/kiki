import json
import os
import io
import zipfile
import sys
from pathlib import Path

def install():
    if os.name!='nt':return
    import winreg
    app=Path(__file__).resolve().parent
    base=Path(os.environ['LOCALAPPDATA'])/'FeatherClock'
    base.mkdir(parents=True,exist_ok=True)
    name='com.featherclock.quota'
    manifest=base/'native-host.json'
    launcher=base/'quota-host.exe'
    py=Path(sys.executable).with_name('python.exe')
    buffer=io.BytesIO()
    with zipfile.ZipFile(buffer,'w') as z:
        z.write(app/'native.py','__main__.py')
    binary=(app/'host-launcher.bin').read_bytes()+f'#!"{py}"\n'.encode('utf8')+buffer.getvalue()
    if not launcher.exists() or launcher.read_bytes()!=binary:
        tmp=launcher.with_suffix('.tmp')
        tmp.write_bytes(binary)
        os.replace(tmp,launcher)
    manifest.write_text(json.dumps(dict(name=name,description='FeatherClock local quota cache',path=str(launcher),type='stdio',allowed_origins=['chrome-extension://'+(app/'extension-id.txt').read_text().strip()+'/'])),encoding='utf8')
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER,r'Software\Microsoft\Edge\NativeMessagingHosts'+'\\'+name) as k:
        winreg.SetValueEx(k,None,0,winreg.REG_SZ,str(manifest))

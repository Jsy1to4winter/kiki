import json
import os
import struct
import sys
import tempfile
from pathlib import Path

def receive(stream):
    (n,)=struct.unpack('<I',stream.read(4))
    if n>16000:raise ValueError()
    payload=json.loads(stream.read(n))
    rows=payload['windows']
    if not isinstance(rows,list) or not 1<=len(rows)<=2:raise ValueError()
    for row in rows:
        if row['name'] not in ('5小时','每周') or not isinstance(row['left'],(int,float)) or not 0<=row['left']<=100:raise ValueError()
        if not isinstance(row['reset'],str) or not 0<len(row['reset'])<=45:raise ValueError()
    from time import time
    return dict(observed=int(time()*1000),windows=rows)

def save_cache(data,base):
    base.mkdir(parents=True,exist_ok=True)
    with tempfile.NamedTemporaryFile(dir=base,mode='w',encoding='utf8',delete=False) as out:
        json.dump(data,out,ensure_ascii=False)
    os.replace(out.name,base/'edge-quota.json')

if __name__=='__main__':
    try:
        data=receive(sys.stdin.buffer)
        save_cache(data,Path(os.environ['LOCALAPPDATA'])/'FeatherClock');answer=b'{"ok":true}'
    except Exception:answer=b'{"ok":false}'
    sys.stdout.buffer.write(struct.pack('<I',len(answer))+answer);sys.stdout.buffer.flush()

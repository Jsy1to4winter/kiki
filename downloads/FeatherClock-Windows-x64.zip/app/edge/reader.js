// Only inspect visible quota text on the signed-in usage page.
function readWindows(text) {
  const lines = text.split(/\n/).map(s => s.trim()).filter(Boolean);
  const result = [];
  const headings = [/5\s*[-‐‑–— ]?\s*(?:hours?|小时|小時|h\b)/i, /weekly|每周|每週|本周|一周|一週|按周/i];
  headings.forEach((re, idx) => {
    for (let i=0; i<lines.length; i++) {
      if (!re.test(lines[i]) || /review|审查|審查/i.test(lines[i])) continue;
      let group=[lines[i]];
      for(let j=i+1;j<Math.min(i+10,lines.length);j++){
        if(headings.some(h=>h.test(lines[j])) || /code review|代码审查|程式碼審查/i.test(lines[j]))break;
        group.push(lines[j]);
      }
      const block=group.join(' ');
      const pct=block.match(/(\d+(?:\.\d+)?)\s*[%％]/);
      const reset=block.match(/(?:resets?(?:\s+(?:at|on|in))?|(?:将于|將於|重置时间|重設時間|重置|重設|刷新)(?:于|於)?)[：:\s]*(.{1,45})/i);
      const before=block.match(/((?:\d{1,2}[月/.-])?\d{1,2}(?:日)?\s*(?:上午|下午)?\s*\d{1,2}:\d{2})\s*(?:重置|重設|刷新)/);
      if (!pct || !/remaining|left|used|剩[余餘]|可用|已用|已使用/i.test(block))continue;
      const used=/used|已用|已使用/i.test(block) && !/remaining|left|剩[余餘]/i.test(block);
      const left=used?100-Number(pct[1]):Number(pct[1]);
      if(left<0 || left>100)continue;
      let when=(before?.[1] || reset?.[1] || '').replace(/^[：:\s]+|\s*(?:重置|重設)$/g,'').trim();
      if(!when || !/\d/.test(when))when='重置时间未显示';
      result.push({name:idx?'每周':'5小时',left,reset:when.slice(0,45)});
      break;
    }
  });
  return result;
}
if (typeof chrome!=='undefined') {
  chrome.runtime.sendMessage({type:'visit'}).catch(()=>{});
  chrome.runtime.onMessage.addListener((m, sender, respond)=>{
    if(m.type==='read' && /^\/codex\/settings\/usage\/?$/.test(location.pathname)){
      respond(readWindows(document.body.innerText));
    }
  });
}

const host='com.featherclock.quota';
const url='https://chatgpt.com/codex/settings/usage';
let busy=false;
async function sync(force=false){
  if(busy)return;
  busy=true;
  let owned;
  try{
    const tabs=await chrome.tabs.query({url:'https://chatgpt.com/*'});
    const state=await chrome.storage.session.get(['checked','owned']);
    const users=tabs.filter(t=>t.id!==state.owned);
    if(!users.length)return;
    if(!force && Date.now()-(state.checked||0)<240000)return;
    await chrome.storage.session.set({checked:Date.now()});
    let page=users.find(t=>t.url?.split(/[?#]/)[0].replace(/\/$/,'')===url);
    if(!page){
      page=await chrome.tabs.create({url,active:false,windowId:users[0].windowId});owned=page.id;
      await chrome.storage.session.set({owned});
    }
    for(let attempt=0;attempt<18;attempt++){
      await new Promise(r=>setTimeout(r,1000));
      let windows;
      try {windows=await chrome.tabs.sendMessage(page.id,{type:'read'});}catch{}
      if(!windows?.length)continue;
      if(owned!==undefined && !(await chrome.tabs.query({url:'https://chatgpt.com/*'})).some(t=>t.id!==owned))break;
      const result=await chrome.runtime.sendNativeMessage(host,{observed:Date.now(),windows});
      if(!result?.ok)throw Error('本机同步未完成');
      break;
    }
  }catch(err){console.warn('羽时同步',String(err));}
  finally{
    if(owned!==undefined){try{await chrome.tabs.remove(owned);}catch{} await chrome.storage.session.remove('owned');}
    busy=false;
  }
}
chrome.runtime.onMessage.addListener((m,sender)=>{
  if(m.type==='visit' && sender.tab && !busy)sync(true);
});
chrome.tabs.onRemoved.addListener(async ()=>{
  if(!(await chrome.tabs.query({url:'https://chatgpt.com/*'})).length)await chrome.storage.session.remove('checked');
});
chrome.alarms.onAlarm.addListener(()=>sync());
chrome.alarms.create('quota',{periodInMinutes:5});
chrome.runtime.onStartup.addListener(()=>sync(true));
chrome.runtime.onInstalled.addListener(()=>sync(true));

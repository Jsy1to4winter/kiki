import json
from pathlib import Path
from datetime import datetime

def read_quota(storage):
    try:
        data=json.loads((Path(storage).parent/'edge-quota.json').read_text(encoding='utf-8'))
        dt=datetime.fromtimestamp(data['observed']/1000)
        rows=[]
        for item in data['windows'][:2]:
            reset=item['reset']
            rows.append(f"{item['name']}余 {item['left']}% · "+(reset if '重置' in reset else reset+' 重置'))
        return dt.strftime('%m/%d %H:%M'),rows
    except (OSError,ValueError,KeyError,TypeError):return '',['等待 Edge 同步','打开网页版 ChatGPT 后更新']

import sys
import os
import json
import math
import random
import time
from pathlib import Path
from datetime import datetime, timedelta
from PyQt5.QtCore import Qt, QPoint, QRectF, QSize, QTimer, QSaveFile, QIODevice, QStandardPaths, QLockFile
from PyQt5.QtGui import QColor, QPainter, QPixmap, QPen, QBrush, QFont, QPainterPath, QIcon, QLinearGradient
from PyQt5.QtWidgets import (QApplication,QWidget,QFrame,QLabel,QPushButton,QToolButton,QLineEdit,QVBoxLayout,QHBoxLayout,QScrollArea,QStackedLayout,QSizePolicy,QMessageBox)

BLUE='#012ea7'
ART=Path(__file__).resolve().parent/'art'
W,H=416,562
EDGE=24
PEEK=96

def font(size,bold=False,latin=False):
    f=QFont('Segoe UI' if latin else QApplication.font().family())
    f.setPixelSize(size);f.setBold(bold);return f

def label(text,size,color,bold=False):
    w=QLabel(text);w.setFont(font(size,bold));w.setStyleSheet('color:'+color);return w

def action(text,tip,handler):
    b=QToolButton();b.setText(text);b.setToolTip(tip);b.setAccessibleName(tip)
    b.clicked.connect(handler);b.setCursor(Qt.PointingHandCursor);return b

def bounded(n,lo,hi):
    return max(lo,min(n,hi))

class Hero(QWidget):
    def __init__(self,owner):
        super().__init__();self.owner=owner;self.setMinimumHeight(195)
        self.pics={p.stem:QPixmap(str(p)) for p in ART.glob('*.png')}
        self.pose='idle';self.start=0;self.next=time.monotonic()+4;self.index=0;self.bubble=0
        self.order=['blush','think','feather','chain'];self.tick=QTimer(self)
        self.tick.timeout.connect(self.advance);self.tick.start(40)
        self.setToolTip('点击角色查看下班倒计时，拖动可移动窗口')
    def advance(self):
        t=time.monotonic()
        if self.isVisible() and t>=self.next:
            self.play(self.order[self.index]);self.index=(self.index+1)%4
        if self.isVisible():self.update()
    def play(self,pose):
        self.pose=pose;self.start=time.monotonic();self.next=self.start+random.uniform(5.8,8.4)
    def clicked(self):
        self.play(random.choice(self.order));self.bubble=time.monotonic()+3.6;self.update()
    def paintEvent(self,event):
        p=QPainter(self);p.setRenderHints(QPainter.Antialiasing|QPainter.SmoothPixmapTransform)
        r=QRectF(self.rect());path=QPainterPath();path.addRoundedRect(r,16,16);p.setClipPath(path)
        p.fillRect(r,QColor('#edf2ff'))
        p.setPen(Qt.NoPen);p.setBrush(QColor('#e1e9ff'));p.drawEllipse(QRectF(self.width()-168,33,200,200))
        p.setPen(QPen(QColor('#c6d4f8'),1));p.setBrush(Qt.NoBrush)
        p.drawEllipse(QRectF(self.width()-175,26,214,214))
        now=datetime.now();w=self.width()
        def txt(x,y,s,px,color,b=False,en=False):
            p.setPen(QColor(color));p.setFont(font(px,b,en));p.drawText(QPoint(x,y),s)
        txt(18,34,'本地时间',12,BLUE,True)
        txt(16,90,now.strftime('%H:%M'),48,'#102558',True,True)
        txt(19,116,f'{now.month:02d}月{now.day:02d}日  ·  星期'+'一二三四五六日'[now.weekday()],12,'#50617f')
        txt(19,self.height()-21,'✦   24 小时制',11,BLUE)
        t=time.monotonic();d=t-self.start
        duration={'blush':2.5,'think':2.8,'feather':1.6,'chain':2.2}.get(self.pose,1)
        a=max(0,min(1,d/.23,(duration-d)/.3))
        dy=1.8*math.sin(t*1.6)
        rect=QRectF(w-184,2+dy,179,self.height()+8)
        if t<self.bubble:rect.translate(0,30)
        p.setOpacity(1-a)
        p.drawPixmap(rect,self.pics['idle'],QRectF(self.pics['idle'].rect()))
        if a:
            pic=self.pics[self.pose];p.setOpacity(a)
            if self.pose=='feather':
                p.translate(rect.center());p.rotate(1.5*math.sin(d*17));p.translate(-rect.center())
            elif self.pose=='chain':rect.translate(0,-2.5*math.sin(math.pi*min(1,d/duration)))
            p.drawPixmap(rect,pic,QRectF(pic.rect()));p.resetTransform();p.setOpacity(1)
        if t<self.bubble:
            tomorrow=(now+timedelta(days=1)).replace(hour=0,minute=0,second=0,microsecond=0)
            msg=f'距下班还有 {math.ceil((tomorrow-now).total_seconds()/60)} 分钟'
            p.setFont(font(12,True));bw=p.fontMetrics().horizontalAdvance(msg)+20
            bx=w-bw-11;by=6;p.setBrush(QColor(BLUE));p.setPen(Qt.NoPen)
            p.drawRoundedRect(QRectF(bx,by,bw,27),11,11)
            tail=QPainterPath();tail.moveTo(w-69,32);tail.lineTo(w-60,32);tail.lineTo(w-64,38);tail.closeSubpath();p.drawPath(tail)
            p.setPen(Qt.white);p.drawText(QRectF(bx,by,bw,27),Qt.AlignCenter,msg)
    def mousePressEvent(self,e):self.owner.press(e)
    def mouseMoveEvent(self,e):self.owner.drag(e)
    def mouseReleaseEvent(self,e):self.owner.release(e,self.clicked if e.x()>=self.width()-188 else None)

class Peek(QWidget):
    def __init__(self,owner):
        super().__init__();self.owner=owner;self.setToolTip('点击展开，拖离边缘后松手也可展开')
        self.setCursor(Qt.OpenHandCursor)
        self.tick=QTimer(self);self.tick.timeout.connect(self.update);self.tick.start(45)
    def paintEvent(self,e):
        p=QPainter(self);p.setRenderHints(QPainter.Antialiasing|QPainter.SmoothPixmapTransform)
        p.translate(self.width()/2,self.height()/2);p.rotate({'bottom':0,'left':90,'right':-90,'top':180}.get(self.owner.edge,0))
        p.translate(-PEEK/2,-PEEK/2);p.scale(PEEK/372,PEEK/361)
        pic=self.owner.hero.pics['peek'];p.drawPixmap(0,0,pic)
        phase=time.monotonic()%4.2
        if phase<.24:
            a=math.sin(math.pi*phase/.24)
            p.setOpacity(a)
            for x,y,span in [(140,230,22),(214,229,26)]:
                lid=QPainterPath();lid.moveTo(x,y+2);lid.quadTo(x+span*.5,y-13,x+span,y)
                lid.quadTo(x+span*.5,y+15,x,y+2);p.fillPath(lid,QColor('#e8c9c9'))
                lash=QPainterPath();lash.moveTo(x,y+2);lash.quadTo(x+span*.5,y+8,x+span,y)
                p.setPen(QPen(QColor('#4d3945'),2.5));p.drawPath(lash)
    def mousePressEvent(self,e):self.owner.press(e)
    def mouseMoveEvent(self,e):self.owner.drag(e)
    def mouseReleaseEvent(self,e):self.owner.release(e,self.owner.expand)

class Window(QWidget):
    def __init__(self,storage):
        super().__init__(None,Qt.Window|Qt.FramelessWindowHint|Qt.WindowStaysOnTopHint)
        self.setWindowTitle('羽时 · 桌面工作窗');self.setAttribute(Qt.WA_TranslucentBackground)
        self.setWindowIcon(QIcon(str(ART/'peek.png')));self.storage=storage;self.tasks=[];self.edge=None
        self.origin=None;self.moved=False;self.build()
        try:data=json.loads(storage.read_text(encoding='utf8'))
        except (OSError,ValueError):data={}
        self.tasks=data.get('tasks',[]) if isinstance(data,dict) else []
        self.renderTasks()
        s=QApplication.primaryScreen().availableGeometry()
        x=data.get('x',s.right()-W-22);y=data.get('y',s.top()+34)
        screen=QApplication.screenAt(QPoint(x,y)) or QApplication.primaryScreen()
        self.normalSize(screen);self.move(self.clamp(QPoint(x,y),screen))
        edge=data.get('edge')
        if edge in ('left','right','top','bottom'):self.dock(edge,QPoint(x,y),screen)
    def normalSize(self,s):
        r=s.availableGeometry();self.setFixedSize(min(W,r.width()),min(H,r.height()))
    def build(self):
        self.setStyleSheet("""
        QWidget{background:transparent;color:#192a4a} QFrame#card{background:white;border:1px solid #b6c7ef;border-radius:18px}
        QToolButton{border:0;background:#f0f4fd;border-radius:7px;color:#012ea7;font-size:16px}
        QToolButton:hover{background:#dce6ff} QLineEdit{background:#f6f8fd;border:1px solid #dbe3f4;border-radius:9px;padding:6px 10px;font-size:13px}
        QLineEdit:focus{border-color:#012ea7} QPushButton{background:#012ea7;color:white;border:0;border-radius:9px;padding:0 13px;font-weight:600}
        QPushButton:hover{background:#1848cb} QScrollBar:vertical{width:5px;background:transparent}
        QScrollBar::handle:vertical{background:#c6d3ed;border-radius:2px;min-height:18px}
        QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{height:0}
        """)
        stack=QStackedLayout(self);stack.setContentsMargins(0,0,0,0)
        self.card=QFrame();self.card.setObjectName('card');stack.addWidget(self.card)
        col=QVBoxLayout(self.card);col.setContentsMargins(16,12,16,14);col.setSpacing(10)
        hdr=QHBoxLayout();hdr.setSpacing(5)
        for sym,tip,cb in [('−','最小化',self.showMinimized),('×','保存并关闭',self.close)]:
            btn=action(sym,tip,cb);btn.setFixedSize(24,24);hdr.addWidget(btn)
        hdr.addStretch();hdr.addWidget(label('✦  羽 时',16,BLUE,True));hdr.addStretch()
        grip=label('⠿',17,'#899abc');grip.setFixedWidth(53);grip.setAlignment(Qt.AlignRight|Qt.AlignVCenter);hdr.addWidget(grip);col.addLayout(hdr)
        self.hero=Hero(self);self.hero.setFixedHeight(196);col.addWidget(self.hero)
        row=QHBoxLayout();row.addWidget(label('工作进度',15,'#172f61',True));row.addStretch();self.stat=label('',12,BLUE,True);row.addWidget(self.stat);col.addLayout(row)
        self.track=QFrame();self.track.setStyleSheet('background:#e8edf8;border-radius:3px');self.track.setFixedHeight(6)
        self.fill=QFrame(self.track);self.fill.setStyleSheet('background:#012ea7;border-radius:3px');col.addWidget(self.track)
        add=QHBoxLayout();self.entry=QLineEdit();self.entry.setPlaceholderText('写下待完成的工作…');self.entry.setMaxLength(240);self.entry.setFixedHeight(36)
        self.entry.returnPressed.connect(self.add);add.addWidget(self.entry)
        b=QPushButton('＋ 新增');b.setCursor(Qt.PointingHandCursor);b.setFixedHeight(36);b.clicked.connect(self.add);add.addWidget(b);col.addLayout(add)
        self.scroll=QScrollArea();self.scroll.setWidgetResizable(True);self.scroll.setFrameShape(QFrame.NoFrame);self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        panel=QWidget();self.rows=QVBoxLayout(panel);self.rows.setAlignment(Qt.AlignTop);self.rows.setContentsMargins(1,0,3,0);self.rows.setSpacing(4)
        self.scroll.setWidget(panel);col.addWidget(self.scroll,1)
        self.peek=Peek(self);stack.addWidget(self.peek);self.stack=stack
    def add(self):
        name=self.entry.text().strip()
        if name:self.tasks.append({'text':name,'done':False});self.entry.clear();self.changed()
    def toggle(self,i):
        self.tasks[i]['done']=not self.tasks[i]['done'];self.changed()
    def changed(self):self.renderTasks();self.save()
    def progress(self):
        n=sum(t['done'] for t in self.tasks);self.fill.setGeometry(0,0,round(self.track.width()*n/max(1,len(self.tasks))),6)
    def renderTasks(self):
        while self.rows.count():
            item=self.rows.takeAt(0);item.widget().hide();item.widget().deleteLater()
        total=len(self.tasks);done=sum(t['done'] for t in self.tasks)
        self.stat.setText(f'{done} / {total} 项完成');self.progress()
        for completed,title in [(False,'待完成'),(True,'已完成')]:
            count=done if completed else total-done
            self.rows.addWidget(label(f'{title}   {count}',12,BLUE,True))
            if not count:
                msg=label('暂无已完成工作' if completed else '暂无待办，可以在上方新增工作',12,'#748199');msg.setContentsMargins(5,5,0,8);self.rows.addWidget(msg)
            for i,t in enumerate(self.tasks):
                if t['done']!=completed:continue
                widget=QWidget();row=QHBoxLayout(widget);row.setContentsMargins(3,3,1,3);row.setSpacing(9)
                b=action('✓' if completed else '', '移回待完成' if completed else '标记完成',lambda _,i=i:self.toggle(i))
                b.setFixedSize(18,18);b.setStyleSheet('border-radius:6px;border:1px solid #a5b8df;'+('background:#012ea7;color:white;font-size:12px' if completed else 'background:white'))
                row.addWidget(b);msg=QLabel(t['text']);msg.setTextFormat(Qt.PlainText);msg.setWordWrap(True)
                f=font(13);f.setStrikeOut(completed);msg.setFont(f);msg.setStyleSheet('color:'+('#8190a5' if completed else '#253957'))
                row.addWidget(msg,1);self.rows.addWidget(widget)
    def save(self):
        f=QSaveFile(str(self.storage));data=json.dumps(dict(tasks=self.tasks,x=self.x(),y=self.y(),edge=self.edge),ensure_ascii=False).encode()
        if not f.open(QIODevice.WriteOnly) or f.write(data)!=len(data) or not f.commit():
            QMessageBox.warning(self,'保存失败','无法保存工作记录，请检查磁盘空间和数据目录权限。')
    def resizeEvent(self,e):
        super().resizeEvent(e)
        if hasattr(self,'fill'):QTimer.singleShot(0,self.progress)
    def press(self,e):
        if e.button()==Qt.LeftButton:self.origin=e.globalPos();self.offset=self.origin-self.pos();self.moved=False;e.accept()
    def drag(self,e):
        if self.origin is None or not e.buttons()&Qt.LeftButton:return
        if (e.globalPos()-self.origin).manhattanLength()>=QApplication.startDragDistance():self.moved=True
        if self.moved:self.move(e.globalPos()-self.offset)
    def clamp(self,p,s):
        r=s.availableGeometry()
        return QPoint(bounded(p.x(),r.left(),r.right()-self.width()+1),bounded(p.y(),r.top(),r.bottom()-self.height()+1))
    def release(self,e,click=None):
        if self.origin is None:return
        self.origin=None
        if not self.moved:
            if click:click()
            return
        s=QApplication.screenAt(e.globalPos()) or self.screen();r=s.availableGeometry();g=self.frameGeometry()
        gaps={'left':max(0,g.left()-r.left()),'right':max(0,r.right()-g.right()),'top':max(0,g.top()-r.top()),'bottom':max(0,r.bottom()-g.bottom())}
        side=min(gaps,key=lambda k:(gaps[k],abs((e.globalX() if k in ('left','right') else e.globalY())-{'left':r.left(),'right':r.right(),'top':r.top(),'bottom':r.bottom()}[k])))
        if gaps[side]<=EDGE:
            anchor=self.pos() if self.edge else e.globalPos()-QPoint(PEEK//2,PEEK//2)
            self.dock(side,anchor,s)
        elif self.edge:self.expand()
        else:self.move(self.clamp(self.pos(),s))
        self.save()
    def dock(self,side,p,s):
        self.edge=side;self.stack.setCurrentWidget(self.peek);self.setFixedSize(PEEK,PEEK)
        r=s.availableGeometry();q=self.clamp(p,s)
        if side=='left':q.setX(r.left())
        if side=='right':q.setX(r.right()-PEEK+1)
        if side=='top':q.setY(r.top())
        if side=='bottom':q.setY(r.bottom()-PEEK+1)
        self.move(q)
    def expand(self):
        s=QApplication.screenAt(self.frameGeometry().center()) or self.screen()
        center=self.frameGeometry().center();self.edge=None;self.stack.setCurrentWidget(self.card);self.normalSize(s)
        self.move(self.clamp(center-QPoint(self.width()//2,self.height()//2),s));self.save()
    def mousePressEvent(self,e):self.press(e)
    def mouseMoveEvent(self,e):self.drag(e)
    def mouseReleaseEvent(self,e):self.release(e)
    def closeEvent(self,e):self.save();super().closeEvent(e)

if __name__=='__main__':
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling);QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps)
    app=QApplication(sys.argv);app.setApplicationName('FeatherClock')
    from PyQt5.QtGui import QFontDatabase
    families=QFontDatabase().families()
    for name in ['Microsoft YaHei UI','PingFang SC','Noto Sans CJK SC']:
        if name in families:app.setFont(QFont(name,10));break
    base=Path(QStandardPaths.writableLocation(QStandardPaths.AppLocalDataLocation));base.mkdir(parents=True,exist_ok=True)
    lock=QLockFile(str(base/'active.lock'))
    if not lock.tryLock(0):
        QMessageBox.information(None,'羽时','羽时已在运行。');sys.exit(0)
    window=Window(base/'work.json');window.show();sys.exit(app.exec_())

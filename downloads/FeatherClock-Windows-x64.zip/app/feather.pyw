import sys
import os
import json
import math
import random
import time
from pathlib import Path
from datetime import datetime, timedelta
from PyQt5.QtCore import Qt, QPoint, QRectF, QSize, QTimer, QSaveFile, QIODevice, QStandardPaths, QLockFile
from PyQt5.QtGui import QColor, QPainter, QPixmap, QPen, QBrush, QFont, QPainterPath, QIcon, QLinearGradient
from PyQt5.QtWidgets import (QApplication,QWidget,QFrame,QLabel,QPushButton,QToolButton,QLineEdit,QVBoxLayout,QHBoxLayout,QScrollArea,QStackedLayout,QSizePolicy,QMessageBox,QMenu,QLayout,QWidgetAction,QSlider,QListWidget,QListWidgetItem)

BLUE='#012ea7'
ART=Path(__file__).resolve().parent/'art'
W,H=432,606
def pet_size(screen):
    # The reference marks about 440 px of standing height on a 1080 px display.
    h=round(screen.geometry().height()*.41)
    return QSize(min(screen.availableGeometry().width(),round(h*.76)),min(screen.availableGeometry().height(),h+54))

EDGE=24
PEEK=96

def font(size,bold=False,latin=False):
    f=QFont('Segoe UI' if latin else QApplication.font().family())
    f.setPixelSize(size);f.setBold(bold);return f

def label(text,size,color,bold=False):
    w=QLabel(text);w.setFont(font(size,bold));w.setStyleSheet('color:'+color);return w

def action(text,tip,handler):
    b=QToolButton();b.setText(text);b.setToolTip(tip);b.setAccessibleName(tip)
    b.clicked.connect(handler);b.setCursor(Qt.PointingHandCursor);return b

def bounded(n,lo,hi):
    return max(lo,min(n,hi))

class Hero(QWidget):
    def __init__(self,owner):
        super().__init__();self.owner=owner;self.setMinimumHeight(195)
        self.pics={p.stem:QPixmap(str(p)) for p in ART.glob('*.png')}
        self.pose='idle';self.start=0;self.next=time.monotonic()+4;self.index=0;self.bubble=0
        self.order=['blush','think','shirt','chain'];self.tick=QTimer(self)
        self.tick.timeout.connect(self.advance);self.tick.start(40)
        self.setToolTip('点击角色查看下班倒计时，拖动可移动窗口')
    def advance(self):
        t=time.monotonic()
        if self.isVisible() and t>=self.next:
            self.play(self.order[self.index]);self.index=(self.index+1)%4
        if self.isVisible():self.update()
    def play(self,pose):
        self.pose=pose;self.start=time.monotonic();self.next=self.start+random.uniform(5.8,8.4)
    def clicked(self):
        self.play(random.choice(self.order));self.bubble=time.monotonic()+3.6;self.update()
    def paintEvent(self,event):
        p=QPainter(self);p.setRenderHints(QPainter.Antialiasing|QPainter.SmoothPixmapTransform)
        r=QRectF(self.rect());path=QPainterPath();path.addRoundedRect(r,16,16);p.setClipPath(path)
        if not self.owner.compact:
            p.fillRect(r,QColor('#edf2ff'))
        p.setPen(Qt.NoPen);p.setBrush(QColor('#e1e9ff'));p.drawEllipse(QRectF(self.width()-168,33,200,200))
        p.setPen(QPen(QColor('#c6d4f8'),1));p.setBrush(Qt.NoBrush)
        p.drawEllipse(QRectF(self.width()-175,26,214,214))
        now=datetime.now();w=self.width()
        def txt(x,y,s,px,color,b=False,en=False):
            p.setPen(QColor(color));p.setFont(font(px,b,en));p.drawText(QPoint(x,y),s)
        date=f'{now.month:02d}月{now.day:02d}日  ·  星期'+'一二三四五六日'[now.weekday()]
        if self.owner.compact:
            txt(84,19,'本地时间',12,BLUE,True)
            txt(16,55,now.strftime('%H:%M'),32,'#102558',True,True)
            txt(19,74,date,11,'#50617f')
        else:
            txt(18,34,'本地时间',12,BLUE,True)
            txt(16,90,now.strftime('%H:%M'),48,'#102558',True,True)
            txt(19,116,date,12,'#50617f')
            txt(19,160,'今天也别忘记吃药',16,BLUE,True)
        t=time.monotonic();d=t-self.start
        duration={'blush':2.5,'think':2.8,'shirt':3.5,'chain':2.2}.get(self.pose,1)
        a=max(0,min(1,d/.23,(duration-d)/.3))
        dy=1.8*math.sin(t*1.6)
        rect=QRectF(w-184,2+dy,179,self.height()+8)
        if t<self.bubble:rect.translate(0,30)
        p.setOpacity(1-a)
        p.drawPixmap(rect,self.pics['idle'],QRectF(self.pics['idle'].rect()))
        if a:
            pic=self.pics[self.pose];p.setOpacity(a)
            if self.pose=='chain':rect.translate(0,-2.5*math.sin(math.pi*min(1,d/duration)))
            p.drawPixmap(rect,pic,QRectF(pic.rect()));p.resetTransform();p.setOpacity(1)
        if t<self.bubble:
            tomorrow=(now+timedelta(days=1)).replace(hour=0,minute=0,second=0,microsecond=0)
            msg=f'距下班还有 {math.ceil((tomorrow-now).total_seconds()/60)} 分钟'
            p.setFont(font(12,True));bw=p.fontMetrics().horizontalAdvance(msg)+20
            bx=w-bw-11;by=6;p.setBrush(QColor(BLUE));p.setPen(Qt.NoPen)
            p.drawRoundedRect(QRectF(bx,by,bw,27),11,11)
            tail=QPainterPath();tail.moveTo(w-69,32);tail.lineTo(w-60,32);tail.lineTo(w-64,38);tail.closeSubpath();p.drawPath(tail)
            p.setPen(Qt.white);p.drawText(QRectF(bx,by,bw,27),Qt.AlignCenter,msg)
    def mousePressEvent(self,e):self.owner.press(e)
    def mouseMoveEvent(self,e):self.owner.drag(e)
    def mouseReleaseEvent(self,e):self.owner.release(e,self.clicked if e.x()>=self.width()-188 else None)

class Pet(QWidget):
    poses = [('blush','你在干嘛…'),('chain','看着我，是快要失控了嘛~'),
             ('shirt','我们距离已经那么近了，但我还是好想你'),('think','想要什么奖励呢')]
    def __init__(self, owner):
        super().__init__()
        self.owner=owner
        self.setCursor(Qt.OpenHandCursor)
        self.setToolTip('单击身体互动，双击展开，拖离边缘可恢复工作窗')
        self.sprites={k[5:]:v for k,v in owner.hero.pics.items() if k.startswith('body_')}
        self.stop()
        self.timer=QTimer(self)
        self.timer.timeout.connect(self.frame)
        self.timer.setTimerType(Qt.PreciseTimer);self.timer.start(16)
    def stop(self):
        self.last=time.monotonic()
        self.serving=False
        self.until=0
        self.pose='idle'
        self.line=''
        self.seated_until=0
        self.next_rest=self.last+30+random.uniform(10,45)
    def frame(self):
        if not self.owner.edge or not self.isVisible():return
        now=time.monotonic()
        if self.owner.origin is None:
            if self.seated_until and now>=self.seated_until:
                self.seated_until=0
                self.until=0
                self.next_rest=now+random.uniform(24,75)
            if not self.seated_until and now-self.last>=30:
                self.serving=True
                if now>=self.next_rest and now>=self.until:
                    self.seated_until=now+30
                    self.line='好累，你在干嘛'
                    self.until=now+5
        self.update()
    def sprite_rect(self,pose,now):
        pic=self.sprites[pose];height=self.height()-54
        if pose=='sit':height*=.62
        width=height*pic.width()/pic.height()
        bob=1+math.sin(now*1.8)
        return QRectF((self.width()-width)/2,self.height()-height-1-bob,width,height)
    def paintEvent(self,e):
        now=time.monotonic()
        p=QPainter(self);p.setRenderHints(QPainter.Antialiasing|QPainter.SmoothPixmapTransform)
        active=now<self.until
        if self.seated_until:
            pose='sit'
        elif self.serving:
            pose='serve_blush' if active else 'serve'
        else:
            pose=self.pose if active else 'idle'
        rect=self.sprite_rect(pose,now)
        p.save()
        pic=self.sprites[pose]
        if active and not self.seated_until and not self.serving:
            age=now-self.last
            fade=max(0,min(1,age/.22,(self.until-now)/.25))
            base=self.sprites['idle']
            p.setOpacity(1-fade);p.drawPixmap(self.sprite_rect('idle',now),base,QRectF(base.rect()))
            p.setOpacity(fade)
            if pose in ('shirt','chain'):rect.translate(0,-2*math.sin(min(1,age/1.2)*math.pi))
        p.drawPixmap(rect,pic,QRectF(pic.rect()))
        if pose=='idle' and now%4.3<.22:
            p.translate(rect.topLeft());p.scale(rect.width()/pic.width(),rect.height()/pic.height())
            p.setOpacity(math.sin(math.pi*(now%4.3)/.22))
            for x,y in [(417,177),(469,174)]:
                p.setPen(Qt.NoPen);p.setBrush(QColor('#e9c7c5'));p.drawEllipse(QRectF(x,y-5,19,9))
                lash=QPainterPath();lash.moveTo(x,y);lash.quadTo(x+9,y+5,x+19,y-2)
                p.setPen(QPen(QColor('#58434c'),2.5));p.setBrush(Qt.NoBrush);p.drawPath(lash)
        p.restore()
        if active:
            p.setFont(font(14,True))
            if self.serving and p.fontMetrics().horizontalAdvance(self.line)>self.width()-28:
                p.setFont(font(11,True))
            p.setPen(Qt.NoPen);p.setBrush(QColor(BLUE))
            bw=min(self.width()-6,p.fontMetrics().horizontalAdvance(self.line)+26)
            cy=max(1,rect.top()-50);mid=self.width()/2
            box=QRectF(mid-bw/2,cy,bw,44);p.drawRoundedRect(box,12,12)
            tail=QPainterPath();tail.moveTo(mid-6,cy+43);tail.lineTo(mid,cy+50);tail.lineTo(mid+6,cy+43);p.drawPath(tail)
            p.setPen(Qt.white);p.drawText(box.adjusted(7,0,-7,0),Qt.AlignCenter|Qt.TextWordWrap,self.line)
    def mousePressEvent(self,e):
        if e.button()==Qt.LeftButton:
            if not self.seated_until and not self.serving:self.stop()
            self.owner.press(e);self.owner.save()
    def mouseMoveEvent(self,e):self.owner.drag(e)
    def mouseReleaseEvent(self,e):
        def interact():
            if self.seated_until:
                self.line='你要好好干活才对'
                self.until=min(self.seated_until,time.monotonic()+4)
                self.update()
                return
            if self.serving:
                self.line='吃我的话不要在这里好不好…'
                self.until=time.monotonic()+4
                self.next_rest=max(self.next_rest,self.until+1)
                self.update()
                return
            r=self.sprite_rect('idle',time.monotonic())
            y=(e.y()-r.top())/r.height()
            idx=0 if y<.204 else 1 if y<.319 else 2 if y<.47 else 3
            self.pose,self.line=self.poses[idx]
            self.last=time.monotonic();self.until=self.last+4;self.update()
        self.owner.release(e,interact)
    def mouseDoubleClickEvent(self,e):
        if e.button()==Qt.LeftButton:
            self.owner.origin=None;self.owner.expand();e.accept()

class ResizeGrip(QWidget):
    def __init__(self,owner,edges):
        super().__init__(owner)
        self.owner=owner;self.edges=edges;self.start=None
        shape={'l':Qt.SizeHorCursor,'r':Qt.SizeHorCursor,'t':Qt.SizeVerCursor,'b':Qt.SizeVerCursor,
               'lt':Qt.SizeFDiagCursor,'rb':Qt.SizeFDiagCursor,'rt':Qt.SizeBDiagCursor,'lb':Qt.SizeBDiagCursor}
        self.setCursor(shape[edges])
    def mousePressEvent(self,e):
        if e.button()==Qt.LeftButton:
            self.start=e.globalPos();self.initial=self.owner.geometry();e.accept()
    def mouseMoveEvent(self,e):
        if self.start is None:return
        w=self.owner;d=e.globalPos()-self.start;r=self.initial
        x,y,ww,hh=r.x(),r.y(),r.width(),r.height()
        if 'l' in self.edges:
            ww=bounded(ww-d.x(),w.minimumWidth(),w.maximumWidth());x=r.right()-ww+1
        if 'r' in self.edges:ww=bounded(ww+d.x(),w.minimumWidth(),w.maximumWidth())
        if 't' in self.edges:
            hh=bounded(hh-d.y(),w.minimumHeight(),w.maximumHeight());y=r.bottom()-hh+1
        if 'b' in self.edges:hh=bounded(hh+d.y(),w.minimumHeight(),w.maximumHeight())
        w.setGeometry(x,y,ww,hh)
    def mouseReleaseEvent(self,e):
        self.start=None;self.owner.save()

class Window(QWidget):
    def __init__(self,storage):
        super().__init__(None,Qt.Window|Qt.FramelessWindowHint|Qt.WindowStaysOnTopHint)
        self.setWindowTitle('羽时 · 桌面工作窗');self.setAttribute(Qt.WA_TranslucentBackground)
        self.setWindowIcon(QIcon(str(ART/'peek.png')));self.storage=storage;self.tasks=[];self.edge=None
        self.origin=None;self.moved=False;self.compact=False;self.build()
        try:data=json.loads(storage.read_text(encoding='utf8'))
        except (OSError,ValueError):data={}
        self.tasks=data.get('tasks',[]) if isinstance(data,dict) else []
        self.opacityPercent=bounded(int(data.get('opacity',100)),30,100)
        self.updateBackground()
        self.renderTasks()
        s=QApplication.primaryScreen().availableGeometry()
        x=data.get('x',s.right()-W-22);y=data.get('y',s.top()+34)
        screen=QApplication.screenAt(QPoint(x,y)) or QApplication.primaryScreen()
        self.savedSize=QSize(int(data.get("width",W)),int(data.get("height",H)))
        self.normalSize(screen);self.move(self.clamp(QPoint(x,y),screen))
        edge=data.get('edge')
        if edge in ('left','right','top','bottom','free'):
            self.dock(edge,QPoint(x,y),screen)
            if edge=='free':
                self.peek.seated_until=time.monotonic()+30
                self.peek.last-=30
    def normalSize(self,s):
        r=s.availableGeometry()
        self.setMaximumSize(r.size());self.setMinimumSize(min(384,r.width()),min(196,r.height()))
        self.resize(self.savedSize.boundedTo(r.size()).expandedTo(self.minimumSize()))
        self.adapt()
    def build(self):
        self.setStyleSheet("""
        QWidget{background:transparent;color:#192a4a} 
        QMenu{background-color:#ffffff;color:#182c52;border:1px solid #aabbd8;padding:4px}
        QMenu::item{background-color:#ffffff;color:#182c52;padding:7px 18px;font-size:15px}
        QMenu::item:selected{background-color:#012ea7;color:#ffffff}
        QToolButton{border:0;background:#f0f4fd;border-radius:7px;color:#012ea7;font-size:16px}
        QToolButton:hover{background:#dce6ff} QLineEdit{background:#f6f8fd;border:1px solid #dbe3f4;border-radius:9px;padding:6px 10px;font-size:13px}
        QLineEdit:focus{border-color:#012ea7} QPushButton{background:#012ea7;color:white;border:0;border-radius:9px;padding:0 13px;font-weight:600}
        QPushButton:hover{background:#1848cb} QScrollBar:vertical{width:5px;background:transparent}
        QScrollBar::handle:vertical{background:#c6d3ed;border-radius:2px;min-height:18px}
        QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{height:0}
        """)
        stack=QStackedLayout(self);stack.setSizeConstraint(QLayout.SetNoConstraint);stack.setContentsMargins(0,0,0,0)
        self.card=QFrame();self.card.setObjectName('card');stack.addWidget(self.card)
        col=QVBoxLayout(self.card);self.col=col;col.setSizeConstraint(QLayout.SetNoConstraint);col.setContentsMargins(16,12,16,14);col.setSpacing(10)
        self.header=QWidget();hdr=QHBoxLayout(self.header);hdr.setContentsMargins(0,0,0,0);hdr.setSpacing(5)
        for sym,tip,cb in [('−','最小化',self.showMinimized),('×','保存并关闭',self.close)]:
            btn=action(sym,tip,cb);btn.setFixedSize(24,24);hdr.addWidget(btn)
        hdr.addStretch();hdr.addWidget(label('✦  羽 时',16,BLUE,True));hdr.addStretch()
        self.settings=action('◐','调节透明度',self.opacityMenu)
        self.settings.setFixedSize(26,24);hdr.addWidget(self.settings);col.addWidget(self.header)
        self.hero=Hero(self);self.hero.setFixedHeight(196);col.addWidget(self.hero)
        self.workPanel=QWidget();work=QVBoxLayout(self.workPanel);work.setContentsMargins(0,0,0,0);work.setSpacing(9)
        col.addWidget(self.workPanel,1)
        row=QHBoxLayout();row.addWidget(label('工作进度',18,'#172f61',True));row.addStretch();self.stat=label('',12,BLUE,True);row.addWidget(self.stat);work.addLayout(row)
        self.track=QFrame();self.track.setStyleSheet('background:#e8edf8;border-radius:3px');self.track.setFixedHeight(6)
        self.fill=QFrame(self.track);self.fill.setStyleSheet('background:#012ea7;border-radius:3px');work.addWidget(self.track)
        add=QHBoxLayout();self.entry=QLineEdit();self.entry.setPlaceholderText('写下待完成的工作…');self.entry.setMaxLength(240);self.entry.setFixedHeight(36)
        self.entry.returnPressed.connect(self.add);add.addWidget(self.entry)
        b=QPushButton('＋ 新增');b.setCursor(Qt.PointingHandCursor);b.setFixedHeight(36);b.clicked.connect(self.add);add.addWidget(b);work.addLayout(add)
        self.scroll=QScrollArea();self.scroll.setWidgetResizable(True);self.scroll.setFrameShape(QFrame.NoFrame);self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        panel=QWidget();self.rows=QVBoxLayout(panel);self.rows.setAlignment(Qt.AlignTop);self.rows.setContentsMargins(1,0,3,0);self.rows.setSpacing(4)
        self.scroll.setWidget(panel);work.addWidget(self.scroll,1)
        self.peek=Pet(self);stack.addWidget(self.peek);self.stack=stack
        self.grips={k:ResizeGrip(self,k) for k in ('l','r','t','b','lt','rt','lb','rb')}
        self.compactControls=QWidget(self.hero)
        ctl=QHBoxLayout(self.compactControls);ctl.setContentsMargins(0,0,0,0);ctl.setSpacing(3)
        for symbol,tip,fn in [('−','最小化',self.showMinimized),('×','关闭',self.close),('◐','调节透明度',self.opacityMenu)]:
            b=action(symbol,tip,fn);b.setFixedSize(21,21);ctl.addWidget(b)
        self.compactControls.adjustSize()
        self.pendingTitle=label('待完成',14,BLUE,True)
        self.pendingTitle.setParent(self.hero)
        self.pending=QListWidget(self.hero)
        self.pending.setAccessibleName('待完成任务')
        self.pending.setFont(font(13))
        self.pending.setFrameShape(QFrame.NoFrame)
        self.pending.setSelectionMode(QListWidget.NoSelection)
        self.pending.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.pending.setStyleSheet(
            'QListWidget{background:transparent;outline:0}'
            'QListWidget::item{min-height:23px}'
            'QListWidget::indicator{width:12px;height:12px;border:1px solid #a5b8df;'
            'border-radius:4px;background:white}'
            'QListWidget::indicator:checked{background:#012ea7}'
        )
        self.pending.viewport().setAutoFillBackground(False)
        self.pending.itemChanged.connect(self.completeCompact)
    def adapt(self):
        if not hasattr(self,'grips'):return
        compact=self.edge is None and self.height()<300
        self.compact=compact
        self.header.setVisible(not compact);self.workPanel.setVisible(not compact)
        self.compactControls.setVisible(compact);self.compactControls.move(6,4)
        self.col.setContentsMargins(*((2,2,2,2) if compact else (16,12,16,14)))
        self.col.setAlignment(Qt.AlignTop)
        self.hero.setFixedHeight(max(192,self.height()-4) if compact else 196)
        left_width=max(105,self.width()-211)
        self.pendingTitle.setGeometry(19,80,left_width,21)
        self.pending.setGeometry(16,103,left_width,max(60,self.hero.height()-111))
        self.pendingTitle.setVisible(compact)
        self.pending.setVisible(compact)
        self.pending.raise_()
        w,h=self.width(),self.height();g=7;c=13
        rects={'l':(0,c,g,h-2*c),'r':(w-g,c,g,h-2*c),'t':(c,0,w-2*c,g),'b':(c,h-g,w-2*c,g),
               'lt':(0,0,c,c),'rt':(w-c,0,c,c),'lb':(0,h-c,c,c),'rb':(w-c,h-c,c,c)}
        for key,grip in self.grips.items():
            grip.setGeometry(*rects[key]);grip.setVisible(self.edge is None);grip.raise_()
    def updateBackground(self):
        alpha=round(255*self.opacityPercent/100)
        self.card.setStyleSheet(
            f'QFrame#card{{background-color:rgba(255,255,255,{alpha});'
            'border:1px solid #b6c7ef;border-radius:18px}'
        )
    def completeCompact(self,item):
        index=item.data(Qt.UserRole)
        if index is not None and item.checkState()==Qt.Checked:
            self.tasks[index]['done']=True
            self.changed()
    def opacityMenu(self):
        button=self.sender()
        menu=QMenu(self)
        panel=QWidget(menu)
        layout=QVBoxLayout(panel);layout.setContentsMargins(12,8,12,9)
        caption=label(f'白色背景不透明度  {self.opacityPercent}%',14,BLUE,True)
        layout.addWidget(caption)
        slider=QSlider(Qt.Horizontal,panel);slider.setRange(30,100)
        slider.setFixedWidth(178);slider.setValue(self.opacityPercent)
        slider.setAccessibleName('白色背景不透明度')
        layout.addWidget(slider)
        def apply(value):
            self.opacityPercent=value;self.updateBackground()
            caption.setText(f'白色背景不透明度  {value}%')
        slider.valueChanged.connect(apply)
        container=QWidgetAction(menu);container.setDefaultWidget(panel);menu.addAction(container)
        menu.exec_(button.mapToGlobal(QPoint(0,button.height())))
        self.save();menu.deleteLater()
    def taskMenu(self,task,widget,point):
        menu=QMenu(self);delete=menu.addAction('删除')
        if menu.exec_(widget.mapToGlobal(point)) is delete:
            self.tasks=[item for item in self.tasks if item is not task];self.changed()
        menu.deleteLater()
    def add(self):
        name=self.entry.text().strip()
        if name:self.tasks.append({'text':name,'done':False});self.entry.clear();self.changed()
    def toggle(self,i):
        self.tasks[i]['done']=not self.tasks[i]['done'];self.changed()
    def changed(self):self.renderTasks();self.save()
    def progress(self):
        n=sum(t['done'] for t in self.tasks);self.fill.setGeometry(0,0,round(self.track.width()*n/max(1,len(self.tasks))),6)
    def renderTasks(self):
        while self.rows.count():
            item=self.rows.takeAt(0);item.widget().hide();item.widget().deleteLater()
        total=len(self.tasks);done=sum(t['done'] for t in self.tasks)
        self.stat.setText(f'{done} / {total} 项完成');self.progress()
        self.pendingTitle.setText(f'待完成  {total-done}')
        self.pending.blockSignals(True)
        self.pending.clear()
        for index, task in enumerate(self.tasks):
            if not task['done']:
                item=QListWidgetItem(task['text'],self.pending)
                item.setToolTip(task['text'])
                item.setData(Qt.UserRole,index)
                item.setCheckState(Qt.Unchecked)
        if not self.pending.count():
            item=QListWidgetItem('暂无待办',self.pending)
            item.setForeground(QColor('#64748b'))
            item.setFlags(Qt.NoItemFlags)
        self.pending.blockSignals(False)
        for completed,title in [(False,'待完成'),(True,'已完成')]:
            count=done if completed else total-done
            self.rows.addWidget(label(f'{title}   {count}',18,BLUE,True))
            if not count:
                msg=label('暂无已完成工作' if completed else '暂无待办，可以在上方新增工作',15,'#64748b');msg.setContentsMargins(5,5,0,8);self.rows.addWidget(msg)
            for i,t in enumerate(self.tasks):
                if t['done']!=completed:continue
                widget=QWidget();row=QHBoxLayout(widget);row.setContentsMargins(3,3,1,3);row.setSpacing(9)
                b=action('✓' if completed else '', '移回待完成' if completed else '标记完成',lambda _,i=i:self.toggle(i))
                b.setFixedSize(23,23);b.setStyleSheet('border-radius:6px;border:1px solid #a5b8df;'+('background:#012ea7;color:white;font-size:12px' if completed else 'background:white'))
                row.addWidget(b);msg=QLabel(t['text']);msg.setTextFormat(Qt.PlainText);msg.setWordWrap(True)
                f=font(15);f.setStrikeOut(completed);msg.setFont(f);msg.setStyleSheet('color:'+('#5c6d85' if completed else '#253957'))
                for child in (widget,b,msg):
                    child.setContextMenuPolicy(Qt.CustomContextMenu)
                    child.customContextMenuRequested.connect(lambda point,c=child,task=t:self.taskMenu(task,c,point))
                row.addWidget(msg,1);self.rows.addWidget(widget)
    def save(self):
        if self.edge is None:self.savedSize=self.size()
        f=QSaveFile(str(self.storage));data=json.dumps(dict(tasks=self.tasks,opacity=self.opacityPercent,x=self.x(),y=self.y(),edge=self.edge,width=self.savedSize.width(),height=self.savedSize.height()),ensure_ascii=False).encode()
        if not f.open(QIODevice.WriteOnly) or f.write(data)!=len(data) or not f.commit():
            QMessageBox.warning(self,'保存失败','无法保存工作记录，请检查磁盘空间和数据目录权限。')
    def resizeEvent(self,e):
        super().resizeEvent(e)
        if hasattr(self,'fill'):self.adapt();QTimer.singleShot(0,self.progress)
    def press(self,e):
        if e.button()==Qt.LeftButton:self.origin=e.globalPos();self.offset=self.origin-self.pos();self.moved=False;e.accept()
    def drag(self,e):
        if self.origin is None or not e.buttons()&Qt.LeftButton:return
        if (e.globalPos()-self.origin).manhattanLength()>=QApplication.startDragDistance():self.moved=True
        if self.moved:self.move(e.globalPos()-self.offset)
    def clamp(self,p,s):
        r=s.availableGeometry()
        return QPoint(bounded(p.x(),r.left(),r.right()-self.width()+1),bounded(p.y(),r.top(),r.bottom()-self.height()+1))
    def release(self,e,click=None):
        if self.origin is None:return
        self.origin=None
        if not self.moved:
            if click:click()
            return
        s=QApplication.screenAt(e.globalPos()) or self.screen();r=s.availableGeometry();g=self.frameGeometry()
        if self.edge and self.peek.seated_until:
            self.edge='free'
            self.setFixedSize(pet_size(s))
            self.move(self.clamp(self.pos(),s))
            self.peek.seated_until=time.monotonic()+30
            self.save()
            return
        gaps={'left':max(0,g.left()-r.left()),'right':max(0,r.right()-g.right()),'top':max(0,g.top()-r.top()),'bottom':max(0,r.bottom()-g.bottom())}
        side=min(gaps,key=lambda k:(gaps[k],abs((e.globalX() if k in ('left','right') else e.globalY())-{'left':r.left(),'right':r.right(),'top':r.top(),'bottom':r.bottom()}[k])))
        if gaps[side]<=EDGE:
            anchor=self.pos() if self.edge else e.globalPos()-QPoint(pet_size(s).width()//2,pet_size(s).height()//2)
            self.dock(side,anchor,s)
        elif self.edge:self.expand()
        else:self.move(self.clamp(self.pos(),s))
        self.save()
    def dock(self,side,p,s):
        if self.edge is None:self.savedSize=self.size()
        self.edge=side;self.stack.setCurrentWidget(self.peek);self.setFixedSize(pet_size(s))
        self.peek.stop();self.adapt()
        r=s.availableGeometry();q=self.clamp(p,s)
        if side=='left':q.setX(r.left())
        if side=='right':q.setX(r.right()-self.width()+1)
        if side=='top':q.setY(r.top())
        if side=='bottom':q.setY(r.bottom()-self.height()+1)
        self.move(q)
    def expand(self):
        s=QApplication.screenAt(self.frameGeometry().center()) or self.screen()
        anchor=self.pos();self.edge=None;self.stack.setCurrentWidget(self.card);self.normalSize(s)
        self.move(self.clamp(anchor,s));self.save()
    def mousePressEvent(self,e):self.press(e)
    def mouseMoveEvent(self,e):self.drag(e)
    def mouseReleaseEvent(self,e):self.release(e)
    def closeEvent(self,e):self.save();super().closeEvent(e)

if __name__=='__main__':
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling);QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps)
    app=QApplication(sys.argv);app.setApplicationName('FeatherClock')
    from PyQt5.QtGui import QFontDatabase
    families=QFontDatabase().families()
    for name in ['Microsoft YaHei UI','PingFang SC','Noto Sans CJK SC']:
        if name in families:app.setFont(QFont(name,10));break
    base=Path(QStandardPaths.writableLocation(QStandardPaths.AppLocalDataLocation));base.mkdir(parents=True,exist_ok=True)
    lock=QLockFile(str(base/'active.lock'))
    if not lock.tryLock(0):
        QMessageBox.information(None,'羽时','羽时已在运行。');sys.exit(0)
    window=Window(base/'work.json');window.show();sys.exit(app.exec_())

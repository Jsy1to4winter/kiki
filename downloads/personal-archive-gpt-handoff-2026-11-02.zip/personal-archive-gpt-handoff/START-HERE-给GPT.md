# 失真档案 · GPT 修改交接说明

日期：2026-11-02（Asia/Shanghai）。当前源码快照：6869f4462e8d5d5914ba1d799d771aa3d2f5fd4c。
这是最新版本，包含 Claude editorial-02 之后的所有已发布调整，尤其是刚缩小至一半的三张链接卡片。不要用历史附件覆盖当前代码。

## 先看这里

当前资料展示页入口：`repository/public/personal-archive/index.html`。
样式：同目录的 `style.css`。
该目录可单独作为完整静态站点发布，全部图片、SVG、音频、歌词和本地 GSAP 均在包内。

仓库根目录的 `repository/index.html` 和 `repository/src/` 属于更早的 Three.js 作品集，**不是当前资料展示页入口**。保留完整仓库是为提供开发上下文，修改当前页面请从 `public/personal-archive/` 入手。

在线页面：https://jsy1to4winter.github.io/kiki/?v=6869f44
仓库：https://github.com/Jsy1to4winter/kiki
最近一次页面部署：https://github.com/Jsy1to4winter/kiki/actions/runs/41343991094
部署工作流：`repository/.github/workflows/personal-archive-pages.yml`。

## 目录说明

- repository/：完整的已跟踪仓库文件，排除旧的交接压缩包，避免反复嵌套打包。包含当前网页和原有工具源码。
- content/：当前须知八段正文、歌词和链接卡片配置的便读副本；网页实际读取的内容仍在 repository 内。
- reference-uploads/：可读取的原始 SVG 文档、视频参考及历史交接 ZIP，仅供参考，不能作为最新版覆盖。
- 发给GPT的提示词.txt：可复制给 GPT 的接续提示词。
- FILES.sha256：包内文件校验清单。

不包含 .git、node_modules、dist、运行缓存或环境凭据。聊天中的所有内嵌参考图并非都有可读取原文件；当前实际使用的处理后背景和人物图片均已完整打包。

## 当前五页

### 1. 自我

人物已改为圆形头像。资料是姓名、年龄、技能、标签、拟化物，采用错落下划线加金色小方块，不再用大号斜线编号；具体值仍为“待填写”。
“关于自我”卡片已删除，自我介绍占满宽度。
关键词区域已改成居中的小椭圆标签，保留金色星星，文字必须为：`锚点：雾山影｜UTC+8`。

### 2. 随笔 / 须知

原“文字随笔 / Unsaid things.”可见标题区和标尺已删除，雨线插图铺满顶部。
原第二篇“将模糊的留下”已删除，保留一个可自然向下增长的“须知”正文区。用户提供的八段正文已原样写入 `.notice-passages`。
字号已按用户要求缩小：手机 11px，电脑 12px。不要自行放大、改写或补全原文最后的“我”。
雨线动效是**整根线条下落**，触地后产生淡金色地面光晕和扩散涟漪；不是短光点沿静止线条移动。
动效由 `rain.js` 和本地 GSAP 驱动；离开栏目、滚出视野、切到后台会暂停；减少动态效果模式显示静态版本。

### 3. 私藏

保留原有两张图片与点击放大功能，配合弧形节点、错落索引和线稿装饰。

### 4. 评价

保留明示的评价占位内容和准星式线稿，不伪造真实评价、名字和数据。

### 5. 痕迹

原标红标题、标尺和“我曾在这里”卡片已经删除，替换成三张可配置链接卡片：片刻记录、偏爱收集、未完之页。下面未标红的月相条仍保留。
链接暂时都为空，显示“链接待添加”，没有 href，不设置虚假的 # 跳转。`trace-links.json` 提供 title、description、url；`link-cards.js` 会在未来配置有效 HTTP/HTTPS 地址后启用整卡跳转。
三张卡片刚按用户要求缩到约一半高度：手机 88px、电脑 135px。为保持紧凑，简介和大装饰图形目前用 CSS 隐藏，配置内容仍保留。不要恢复成之前的大卡片。
用户说以后再做编辑页，**当前未添加编辑页面或编辑按钮**。

## 关键脚本

- app.js：封面、五页导航、触摸滑动、图片弹窗和切页动效。
- music.js + music-tracks.json：单个常驻 audio、两曲循环、歌词与媒体控制。
- rain.js：GSAP 整线下落、触地光晕、暂停和清理。
- link-cards.js + trace-links.json：三张卡片的显示内容和链接绑定。
- assets/vendor/：从锁文件安装的 GSAP 复制的本地分发文件、source map 和来源说明。无需外部 CDN。

## 切页和手机交互

用户明确要求镜头向前推进，其余部分模糊切换到下一页。
支持 View Transitions 的浏览器用平面截图动画；命名的是 `.scene:not([hidden])`，而不是父容器 `#camera`。给父容器设置 view-transition-name 会隔离 backdrop，导致磨砂变淡，已修复，不要改回。
兼容浏览器使用 GSAP 推进内容层，保持外层磨砂稳定。减少动态效果模式直接切页。连续快速点击使用最后目标队列，不丢失用户最后的选择。
图片弹窗关闭按钮的白色外圈已去掉；手机点击无焦点环，键盘导航保留金色焦点提示。
导航和按钮使用 touch-action: manipulation，并限制导航双击误放大；保留用户主动双指缩放。
底部导航电脑和手机都约 240×48 CSS 像素。用户会在电脑上直接拖窄浏览器窗口查看手机布局。

## 音乐与歌词

两首原音频完整保留：`assets/the-guilt.mp3`、`assets/thelema.mp3`。
音乐按钮首次点开展开；展开后再次点图标切换下一首并自动收回；暂停按钮单独操作。
页面尝试自动播放，但手机可能阻止有声自动播放；第一次点击封面时再次尝试播放，不要声称能绕过浏览器策略。
播放、歌名和歌词区域不属于某个栏目，切页不能重建 audio 或重置播放位置。
《假贵族》有用户提供的 68 行歌词，无逐句时间戳，按音频时长均匀轮播，不是精确 LRC 同步。《Thelema》暂无歌词。

## 本地运行

当前页面是纯静态 HTML/CSS/JS，无后端或必需密钥。
用完整仓库运行（已验证 Node.js 24.19.0、npm 11.9.0；README 要求 Node.js 22.12+）：

```sh
cd repository
npm ci
npm run dev -- --port 5174 --strictPort
```

打开开发服务的 `/personal-archive/` 路径。`npm run build` 将素材复制到 `dist/personal-archive/`。
也可用静态 HTTP 服务指向 `repository/public/personal-archive/`。不要只双击 index.html：音乐、卡片脚本会 fetch JSON，file 协议可能被限制。

## 发布和交付偏好

GitHub Actions 在 main 上的 `public/personal-archive/**` 更新时，将该目录直接发布到 GitHub Pages 根路径。
用户希望每次修改后得到两个链接：新版网页链接，以及下一行对应的 GitHub Actions 部署状态链接。只有核实成功后才写“已成功”。无法访问 GitHub 时，应提供完整可替换文件，并诚实说明未部署。
更换 CSS/JS 时更新 index.html 引用的版本参数，避免旧缓存。

## 设计约束和待补内容

灰白、教堂光影、金色点缀、透明磨砂；磨砂卡片应比背景更清楚但能看见背景。装饰保持抽象细线，不突兀、不写实。
个人资料、真实自介和评价尚待用户补全，不能自行虚构。未来需要编辑页时再按用户指令制作，不要提前加入。
这次本包只做整理，没有修改线上网页。

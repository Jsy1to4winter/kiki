import * as THREE from "three";
import {
  peelShadowDepthFragmentShader,
  peelShadowDepthVertexShader,
  residueFragmentShader,
  residueVertexShader,
  stickerFragmentShader,
  stickerVertexShader,
} from "./shaders";
import {
  DEFAULT_PEEL_SOUND_URL,
  PeelAudioEngine,
} from "./peel-audio";
import { getLaserEffectSettings } from "./laser-debug";
import { createMaterialPreviewCanvas } from "./material-preview";
import { prepareArtwork, type PreparedArtwork } from "./source";
import {
  resolveStickerOptions,
  stickerMaterialTypeIndex,
  type ResolvedStickerOptions,
  type StickerInstance,
  type StickerOptions,
  type StickerPlaybackMotion,
  type StickerPoint,
  type StickerRenderSnapshot,
  type PreparedStickerSource,
  type StickerSource,
  type StickerState,
  type StickerTextSource,
} from "./types";

export type {
  StickerBackOptions,
  StickerDisplayOptions,
  StickerEdgeOptions,
  StickerInstance,
  StickerMaterialOptions,
  StickerMaterialType,
  PreparedStickerSource,
  StickerImageSource,
  StickerLightingOptions,
  StickerLightDirection,
  StickerOptions,
  StickerOutlineOptions,
  StickerPeelOptions,
  StickerPoint,
  StickerRenderSnapshot,
  StickerPlaybackMotion,
  StickerRichTextBlock,
  StickerRichTextDocument,
  StickerRichTextRun,
  StickerShadowOptions,
  StickerSoundOptions,
  StickerSource,
  StickerState,
  StickerSvgSource,
  StickerTextSource,
} from "./types";
export {
  imageSourceHasTransparency,
  sanitizeSvgMarkup,
} from "./source";

const DEFAULT_SOURCE: StickerTextSource = {
  type: "text",
  text: "PEEL ME\n@cats_juice",
  color: "#19191d",
  fontFamily: "Arial Rounded MT Bold, Arial Black, sans-serif",
  fontWeight: 900,
  richText: {
    blocks: [
      {
        align: "center",
        lineHeight: 1.2,
        runs: [
          { text: "PEEL ", color: "#19191d", fontSize: 28, fontWeight: 900 },
          {
            text: "ME",
            color: "rgb(36, 126, 245)",
            fontSize: 28,
            fontWeight: 900,
          },
        ],
      },
      {
        align: "center",
        lineHeight: 0.8,
        runs: [
          {
            text: "@cats_juice",
            color: "#19191d",
            fontSize: 10,
            fontWeight: 500,
          },
        ],
      },
    ],
  },
};

const MIN_CURL_ANGLE = 2.55;
const MAX_CURL_ANGLE = Math.PI;
const MAX_FRONT_TO_POINTER_RATIO = 1.28;
const DIRECTION_DEAD_ZONE = 0.004;
const OUTWARD_DIRECTION_LIMIT = -0.22;
// Small backwards movements remain directly coupled to the pointer. Larger
// drops are eased so sparse/coalesced pointer events cannot flatten the peel
// in one rendered frame.
const MAX_DIRECT_RETURN_STEP_RATIO = 0.035;
// Releasing a partially peeled sticker should reattach. The final quarter is
// reserved for the deliberate, long pull that completes the detachment.
const SNAP_DETACH_THRESHOLD = 0.74;
const MAX_STICKER_WIDTH_PX = 760;
const MAX_STICKER_HEIGHT_PX = 520;
export const STICKER_ENTRANCE_DURATION_MS = 720;
const ENTRANCE_SCALE_DURATION = STICKER_ENTRANCE_DURATION_MS / 1000;
const ENTRANCE_SWEEP_DELAY = 0.06;
const ENTRANCE_SWEEP_DURATION = 0.42;
const PRE_ENTRANCE_DURATION = 0.32;
const INTERACTION_HINT_DURATION = 0.9;
const INTERACTION_HINT_COLOR = "rgb(36, 126, 245)";

type MutableStickerState = {
  ready: boolean;
  dragging: boolean;
  progress: number;
  grabPoint: StickerPoint | null;
  pointer: StickerPoint | null;
};

type PreparedEntrance = {
  artwork: PreparedArtwork;
  texture: THREE.CanvasTexture;
  source: StickerSource;
  options: Partial<StickerOptions>;
  elapsed: number;
};

type PreparedSourcePayload = {
  artwork: PreparedArtwork;
  texture: THREE.CanvasTexture;
  source: StickerSource;
  options: Partial<StickerOptions>;
};

type PreparedSourceAction = "commit" | "entrance" | "dispose";

type PreparedSourceHandleState = {
  payload: PreparedSourcePayload | null;
  consume:
    | ((action: PreparedSourceAction, payload: PreparedSourcePayload) => void)
    | null;
};

function takePreparedSourceState(state: PreparedSourceHandleState) {
  const payload = state.payload;
  const consume = state.consume;
  state.payload = null;
  state.consume = null;
  return { payload, consume };
}

function consumePreparedSourceState(
  state: PreparedSourceHandleState,
  action: PreparedSourceAction,
) {
  const { payload, consume } = takePreparedSourceState(state);
  if (payload && consume) consume(action, payload);
}

function createPreparedSourceHandle(
  state: PreparedSourceHandleState,
): PreparedStickerSource {
  return {
    commit() {
      consumePreparedSourceState(state, "commit");
    },
    commitWithEntrance() {
      consumePreparedSourceState(state, "entrance");
    },
    dispose() {
      consumePreparedSourceState(state, "dispose");
    },
  };
}

type EdgeHit = {
  local: THREE.Vector2;
  inward: THREE.Vector2;
};

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value));
}

function smoothstep(edge0: number, edge1: number, value: number) {
  const progress = clamp((value - edge0) / (edge1 - edge0), 0, 1);
  return progress * progress * (3 - 2 * progress);
}

function colorFrom(value: string, fallback: string) {
  try {
    return new THREE.Color(value);
  } catch {
    return new THREE.Color(fallback);
  }
}

function mergePublicOptions(
  current: Partial<StickerOptions>,
  patch: Partial<StickerOptions>,
): Partial<StickerOptions> {
  return {
    ...current,
    ...patch,
    outline: { ...current.outline, ...patch.outline },
    edge: { ...current.edge, ...patch.edge },
    shadow: { ...current.shadow, ...patch.shadow },
    lighting: {
      ...current.lighting,
      ...patch.lighting,
      direction:
        patch.lighting?.direction ?? current.lighting?.direction,
    },
    peel: { ...current.peel, ...patch.peel },
    back: { ...current.back, ...patch.back },
    material: { ...current.material, ...patch.material },
    sound: { ...current.sound, ...patch.sound },
    display: { ...current.display, ...patch.display },
  };
}

class StickerRenderer implements StickerInstance {
  private readonly container: HTMLElement;
  private readonly renderer: THREE.WebGLRenderer;
  private readonly camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.01, 10);
  private readonly scene = new THREE.Scene();
  private readonly uniforms: Record<string, THREE.IUniform>;
  private readonly stickerMaterial: THREE.ShaderMaterial;
  private readonly residueMaterial: THREE.ShaderMaterial;
  private readonly peelAudio = new PeelAudioEngine();
  private readonly peelShadowDepthMaterial: THREE.ShaderMaterial;
  private readonly groundShadowGeometry = new THREE.PlaneGeometry(1, 1);
  private readonly groundShadowMaterial: THREE.ShadowMaterial;
  private readonly stickerMesh: THREE.Mesh<THREE.PlaneGeometry, THREE.ShaderMaterial>;
  private readonly residueMesh: THREE.Mesh<THREE.PlaneGeometry, THREE.ShaderMaterial>;
  private readonly groundShadowMesh: THREE.Mesh<
    THREE.PlaneGeometry,
    THREE.ShadowMaterial
  >;
  private readonly peelShadowLight = new THREE.DirectionalLight(0xffffff, 1);
  private readonly peelShadowTarget = new THREE.Object3D();
  private geometry = new THREE.PlaneGeometry(1, 1, 2, 2);
  private texture: THREE.CanvasTexture | null = null;
  private artwork: PreparedArtwork | null = null;
  private options: ResolvedStickerOptions;
  private source: StickerSource = DEFAULT_SOURCE;
  private requestedSource: StickerSource = DEFAULT_SOURCE;
  private sourceRevision = 0;
  private sourceRebuildTimer: number | null = null;
  private readonly preparedSourceStates =
    new Set<PreparedSourceHandleState>();
  private destroyed = false;
  private resizeObserver: ResizeObserver | null = null;
  private resizeFrameRequest = 0;
  private renderedWidth = 0;
  private renderedHeight = 0;
  private renderedPixelRatio = 0;
  private measuredClientWidth = -1;
  private measuredClientHeight = -1;
  private geometryWidth = 1;
  private geometryHeight = 1;
  private geometrySegmentsX = 2;
  private geometrySegmentsY = 2;
  private viewWidth = 2;
  private viewHeight = 2;
  private viewportHeightPx = 420;
  private renderScale = 1;
  private meshWidth = 1.6;
  private meshHeight = 0.62;
  private pointerId: number | null = null;
  private grabOrigin = new THREE.Vector2(-0.8, 0);
  private grabStart = new THREE.Vector2();
  private grabDirection = new THREE.Vector2(1, 0);
  private activeDirection = new THREE.Vector2(1, 0);
  private grabExtent = 1.6;
  private creaseDepth = 0;
  private basePeelRadius = 0.08;
  private effectivePeelRadius = 0.08;
  private grabProjection = 0;
  private springVelocity = 0;
  private springActive = false;
  private springTargetDepth = 0;
  private dragDetached = false;
  private detachedTension = 0;
  private detachedExitActive = false;
  private detachedExitElapsed = 0;
  private detachedExitSpin = 0;
  private entranceActive = false;
  private entranceElapsed = 0;
  private preparedEntrance: PreparedEntrance | null = null;
  private backgroundRemovalEffectActive = false;
  private backgroundRemovalEffectElapsed = 0;
  private interactionHintActive = false;
  private interactionHintElapsed = 0;
  private readonly entranceAxis = new THREE.Vector2(1, 0);
  private readonly reducedMotionQuery = window.matchMedia(
    "(prefers-reduced-motion: reduce)",
  );
  private hoverFrameRequest = 0;
  private hoverClientX = 0;
  private hoverClientY = 0;
  private frameRequest = 0;
  private lastFrameTime = 0;
  private state: MutableStickerState = {
    ready: false,
    dragging: false,
    progress: 0,
    grabPoint: null,
    pointer: null,
  };

  constructor(container: HTMLElement, options: StickerOptions = {}) {
    this.container = container;
    this.options = resolveStickerOptions(undefined, options);
    this.camera.position.z = 3;

    this.renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: true,
      powerPreference: "high-performance",
      premultipliedAlpha: true,
      preserveDrawingBuffer: true,
    });
    this.renderer.setClearColor(0x000000, 0);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    this.renderer.domElement.style.width = "100%";
    this.renderer.domElement.style.height = "100%";
    this.renderer.domElement.style.display = "block";
    this.renderer.domElement.style.touchAction = "none";
    this.renderer.domElement.style.cursor = "default";
    this.renderer.domElement.tabIndex = 0;
    this.renderer.domElement.setAttribute("role", "slider");
    this.renderer.domElement.setAttribute("aria-valuemin", "0");
    this.renderer.domElement.setAttribute("aria-valuemax", "100");
    this.renderer.domElement.setAttribute("aria-valuenow", "0");
    this.renderer.domElement.setAttribute(
      "aria-label",
      "Interactive sticker. Drag a visible edge, or use arrow keys to preview the peel.",
    );
    this.renderer.domElement.setAttribute(
      "aria-keyshortcuts",
      "ArrowUp ArrowRight ArrowDown ArrowLeft Space",
    );

    this.uniforms = {
      uMap: { value: null },
      uPreparedMap: { value: null },
      uPreparedMix: { value: 0 },
      uPeel: { value: 0 },
      uPeelDepth: { value: 0 },
      uDetachedTension: { value: 0 },
      uRadius: { value: 0.08 },
      uMaxAngle: { value: 3.55 },
      uWind: { value: this.options.wind },
      uTime: { value: 0 },
      uOrigin: { value: this.grabOrigin.clone() },
      uPeelDir: { value: this.activeDirection.clone() },
      uMeshSize: { value: new THREE.Vector2(this.meshWidth, this.meshHeight) },
      uTexel: { value: new THREE.Vector2(1 / 1024, 1 / 512) },
      uEdgeFinishScale: { value: 1 },
      uEdgeBevelWidth: { value: this.options.edge.width },
      uEdgeFinishStrength: { value: this.options.edge.strength },
      uBackColor: { value: colorFrom(this.options.back.color, "#f7f5f2") },
      uGloss: { value: this.options.back.gloss },
      uRoughness: { value: this.options.back.roughness },
      uLightDirection: {
        value: new THREE.Vector3(
          this.options.lighting.direction.x,
          this.options.lighting.direction.y,
          this.options.lighting.direction.z,
        ).normalize(),
      },
      uLightIntensity: { value: this.options.lighting.intensity },
      uAmbientLight: { value: this.options.lighting.ambient },
      uLightSoftness: { value: this.options.lighting.softness },
      uMaterialType: {
        value: stickerMaterialTypeIndex(this.options.material.type),
      },
      uMaterialIntensity: { value: this.options.material.intensity },
      uMaterialScale: { value: this.options.material.scale },
      uHolographicGrain: {
        value: this.options.material.holographicGrain,
      },
      uMaterialSeed: { value: this.options.material.seed },
      uMaterialBaked: { value: 0 },
      uHolographicColorA: {
        value: colorFrom(
          this.options.material.holographicColors[0],
          "#f2a7c5",
        ),
      },
      uHolographicColorB: {
        value: colorFrom(
          this.options.material.holographicColors[1],
          "#8edfd5",
        ),
      },
      uHolographicColorC: {
        value: colorFrom(
          this.options.material.holographicColors[2],
          "#9db4ea",
        ),
      },
      uShadowColor: {
        value: colorFrom(this.options.shadow.color, "#191823"),
      },
      uShadowOpacity: { value: this.options.shadow.opacity },
      uSurfaceShadowEnabled: {
        value: this.options.peel.surfaceShadow ? 1 : 0,
      },
      uShadowBlur: { value: this.options.shadow.blur },
      uShadowDistance: { value: 0.04 },
      uShadowDirection: { value: new THREE.Vector2(0.7, -0.7) },
      uEntranceSweep: { value: -1 },
      uEntranceAxis: { value: this.entranceAxis.clone() },
      uEntranceScaleProgress: { value: -1 },
      uPreEntranceProgress: { value: 0 },
      uLaserCoreWidth: { value: 0.04 },
      uLaserBandWidth: { value: 0.3 },
      uLaserBandOpacity: { value: 0.46 },
      uLaserBrightness: { value: 1.18 },
      uLaserHighlightIntensity: { value: 0.62 },
      uBackgroundRemovalDistortion: { value: 0 },
      uRemovalDistortionRange: { value: 0.37 },
      uRemovalDistortionStrength: { value: 2.25 },
      uRemovalRippleDensity: { value: 12 },
      uRemovalRippleSpeed: { value: 4.2 },
      uInteractionHint: { value: 0 },
      uInteractionHintRadius: { value: 3 },
      uInteractionHintColor: {
        value: colorFrom(INTERACTION_HINT_COLOR, "rgb(36, 126, 245)"),
      },
      // Keep the resting face pixel-identical to the baked Gallery preview.
      // The shader fades this protection as soon as the sticker deforms, so
      // lighting still responds during peel/drag interaction.
      uPreserveFrontColor: { value: 1 },
      uOpacity: { value: 1 },
    };

    const stickerUniforms = {
      ...THREE.UniformsUtils.clone(THREE.UniformsLib.lights),
      ...this.uniforms,
    };
    this.stickerMaterial = new THREE.ShaderMaterial({
      uniforms: stickerUniforms,
      vertexShader: stickerVertexShader,
      fragmentShader: stickerFragmentShader,
      lights: true,
      side: THREE.DoubleSide,
      transparent: true,
      depthTest: true,
      depthWrite: true,
    });
    this.stickerMaterial.alphaTest = 0.008;
    this.stickerMesh = new THREE.Mesh(this.geometry, this.stickerMaterial);
    this.stickerMesh.renderOrder = 20;
    this.stickerMesh.receiveShadow = true;

    this.residueMaterial = new THREE.ShaderMaterial({
      uniforms: { ...this.uniforms },
      vertexShader: residueVertexShader,
      fragmentShader: residueFragmentShader,
      transparent: true,
      depthTest: true,
      depthWrite: false,
      toneMapped: false,
    });
    this.residueMesh = new THREE.Mesh(this.geometry, this.residueMaterial);
    this.residueMesh.position.z = -0.006;
    this.residueMesh.renderOrder = 10;

    this.peelShadowDepthMaterial = new THREE.ShaderMaterial({
      uniforms: { ...this.uniforms },
      vertexShader: peelShadowDepthVertexShader,
      fragmentShader: peelShadowDepthFragmentShader,
      side: THREE.DoubleSide,
      depthTest: true,
      depthWrite: true,
    });
    this.stickerMesh.castShadow = true;
    this.stickerMesh.customDepthMaterial = this.peelShadowDepthMaterial;

    this.peelShadowLight.castShadow = true;
    this.peelShadowLight.shadow.mapSize.set(
      this.options.quality === "high" ? 2048 : 1024,
      this.options.quality === "high" ? 2048 : 1024,
    );
    this.peelShadowLight.shadow.bias = -0.0001;
    this.peelShadowLight.shadow.normalBias = 0.0015;
    this.peelShadowLight.target = this.peelShadowTarget;
    this.scene.add(this.peelShadowTarget, this.peelShadowLight);

    this.groundShadowMaterial = new THREE.ShadowMaterial({
      color: colorFrom(this.options.shadow.color, "#191823"),
      opacity: this.options.shadow.opacity,
      transparent: true,
      depthTest: true,
      depthWrite: false,
      toneMapped: false,
    });
    this.groundShadowMesh = new THREE.Mesh(
      this.groundShadowGeometry,
      this.groundShadowMaterial,
    );
    this.groundShadowMesh.position.z = -0.012;
    this.groundShadowMesh.receiveShadow = true;
    this.groundShadowMesh.renderOrder = 5;
    this.scene.add(this.groundShadowMesh);
    this.scene.add(this.residueMesh);
    this.scene.add(this.stickerMesh);

    try {
      this.attach();
    } catch (error) {
      this.destroy();
      throw error;
    }
  }

  private attach() {
    const canvas = this.renderer.domElement;
    this.container.appendChild(canvas);
    canvas.addEventListener("pointerdown", this.onPointerDown);
    canvas.addEventListener("pointermove", this.onPointerMove);
    canvas.addEventListener("pointerup", this.onPointerUp);
    canvas.addEventListener("pointercancel", this.onPointerUp);
    canvas.addEventListener("lostpointercapture", this.onLostPointerCapture);
    canvas.addEventListener("pointerleave", this.onPointerLeave);
    canvas.addEventListener("keydown", this.onKeyDown);
    canvas.addEventListener("webglcontextlost", this.onContextLost);
    window.addEventListener("pointerup", this.onWindowPointerEnd, true);
    window.addEventListener("pointercancel", this.onWindowPointerEnd, true);
    window.addEventListener("blur", this.onWindowBlur);
    document.addEventListener("visibilitychange", this.onVisibilityChange);

    if (typeof ResizeObserver !== "undefined") {
      this.resizeObserver = new ResizeObserver(this.resizeObserved);
      this.resizeObserver.observe(this.container);
    } else {
      window.addEventListener("resize", this.scheduleResize);
    }

    this.resize();
  }

  async setSource(source: StickerSource): Promise<void> {
    if (this.destroyed) return;
    this.cancelPreparedEntrance();
    this.requestedSource = source;
    if (this.sourceRebuildTimer !== null) {
      window.clearTimeout(this.sourceRebuildTimer);
      this.sourceRebuildTimer = null;
    }
    const revision = ++this.sourceRevision;
    try {
      const artwork = await prepareArtwork(source, this.options.outline);
      if (this.destroyed || revision !== this.sourceRevision) return;
      this.source = source;
      this.options.source = source;
      this.applyArtwork(artwork);
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "The sticker source failed to render.";
      this.emit("error", { message });
      throw error;
    }
  }

  async prepareSource(
    source: StickerSource,
    options: Partial<StickerOptions> = {},
  ): Promise<PreparedStickerSource> {
    if (this.destroyed) {
      throw new Error("The sticker renderer has been destroyed.");
    }
    const preparedOptions = resolveStickerOptions(this.options, options);
    const artwork = await prepareArtwork(source, preparedOptions.outline);
    if (this.destroyed) {
      throw new Error("The sticker renderer has been destroyed.");
    }
    const texture = this.createArtworkTexture(
      artwork,
      preparedOptions.material,
      preparedOptions.lighting,
    );
    try {
      this.renderer.initTexture(texture);
    } catch (error) {
      texture.dispose();
      throw error;
    }
    const state: PreparedSourceHandleState = {
      payload: { artwork, texture, source, options },
      consume: null,
    };
    state.consume = (action, prepared) => {
      this.preparedSourceStates.delete(state);
      if (action === "dispose" || this.destroyed) {
        prepared.texture.dispose();
        return;
      }
      if (action === "commit") {
        this.sourceRevision += 1;
        this.requestedSource = prepared.source;
        this.source = prepared.source;
        this.options = resolveStickerOptions(this.options, {
          ...prepared.options,
          source: prepared.source,
        });
        this.applyArtwork(prepared.artwork, prepared.texture);
        return;
      }
      if (action === "entrance") {
        this.cancelPreparedEntrance();
        this.entranceActive = false;
        this.clearEntrancePose();
        this.preparedEntrance = {
          artwork: prepared.artwork,
          texture: prepared.texture,
          source: prepared.source,
          options: prepared.options,
          elapsed: 0,
        };
        this.uniforms.uPreparedMap.value = prepared.texture;
        this.uniforms.uPreparedMix.value = 0;
        this.uniforms.uPreEntranceProgress.value = 0;
        this.requestRender();
      }
    };
    this.preparedSourceStates.add(state);
    return createPreparedSourceHandle(state);
  }

  setOptions(patch: Partial<StickerOptions>): void {
    if (this.destroyed) return;
    const previousOutline = this.options.outline;
    const previousQuality = this.options.quality;
    const previousDisplay = this.options.display;
    const previousMaterialKey = this.materialKey();
    this.options = resolveStickerOptions(this.options, patch);
    if (
      this.artwork &&
      this.materialKey() !== previousMaterialKey &&
      !patch.source
    ) {
      this.refreshMaterialTexture();
    }

    if (patch.source) {
      void this.setSource(patch.source).catch(() => {
        // setSource emits the actionable error detail.
      });
    }
    const outlineChanged =
      patch.outline &&
      (this.options.outline.width !== previousOutline.width ||
        this.options.outline.color !== previousOutline.color);
    if (outlineChanged && !patch.source) {
      if (this.sourceRebuildTimer !== null) {
        window.clearTimeout(this.sourceRebuildTimer);
      }
      this.sourceRebuildTimer = window.setTimeout(() => {
        this.sourceRebuildTimer = null;
        void this.setSource(this.requestedSource).catch(() => {
          // setSource emits the actionable error detail.
        });
      }, 70);
    }
    if (
      (this.options.quality !== previousQuality ||
        this.options.display.width !== previousDisplay.width ||
        this.options.display.height !== previousDisplay.height) &&
      this.artwork
    ) {
      this.updateMeshGeometry(this.artwork.aspect);
    }
    this.applyOptionsToRenderer();
    this.requestRender();
  }

  reset(): void {
    const activePointerId = this.pointerId;
    this.pointerId = null;
    this.state.dragging = false;
    if (
      activePointerId !== null &&
      this.renderer.domElement.hasPointerCapture(activePointerId)
    ) {
      this.renderer.domElement.releasePointerCapture(activePointerId);
    }
    this.springActive = false;
    this.springVelocity = 0;
    this.springTargetDepth = 0;
    this.dragDetached = false;
    this.detachedTension = 0;
    this.detachedExitActive = false;
    this.detachedExitElapsed = 0;
    this.detachedExitSpin = 0;
    this.entranceActive = false;
    this.entranceElapsed = 0;
    this.interactionHintActive = false;
    this.interactionHintElapsed = 0;
    this.stickerMesh.position.set(0, 0, 0);
    this.stickerMesh.scale.set(1, 1, 1);
    this.stickerMesh.rotation.z = THREE.MathUtils.degToRad(this.options.tilt);
    this.uniforms.uEntranceSweep.value = -1;
    this.uniforms.uEntranceScaleProgress.value = -1;
    this.uniforms.uInteractionHint.value = 0;
    this.peelAudio.reset(0);
    this.setCreaseDepth(0);
    this.state.pointer = null;
    this.state.grabPoint = null;
    this.renderer.domElement.style.cursor = "default";
    this.updatePeelUniforms();
    this.emit("peelchange", { amount: 0, progress: 0 });
    this.requestRender();
  }

  setPeelProgress(
    progress: number,
    motion: StickerPlaybackMotion = {
      origin: { x: 0, y: 0.5 },
      target: { x: 1, y: 0.5 },
    },
  ): void {
    if (this.destroyed || !this.artwork) return;
    this.springActive = false;
    this.springVelocity = 0;
    this.detachedExitActive = false;
    this.entranceActive = false;
    this.interactionHintActive = false;
    this.state.dragging = false;
    this.stickerMesh.position.set(0, 0, 0);
    this.stickerMesh.scale.set(1, 1, 1);
    this.stickerMesh.rotation.z = THREE.MathUtils.degToRad(this.options.tilt);
    this.uniforms.uEntranceSweep.value = -1;
    this.uniforms.uEntranceScaleProgress.value = -1;
    this.uniforms.uInteractionHint.value = 0;

    const originX = clamp(motion.origin.x, 0, 1) - 0.5;
    const originY = 0.5 - clamp(motion.origin.y, 0, 1);
    const targetX = motion.target.x - 0.5;
    const targetY = 0.5 - motion.target.y;
    this.grabOrigin.set(originX * this.meshWidth, originY * this.meshHeight);
    const targetDeltaX = (targetX - originX) * this.meshWidth;
    const targetDeltaY = (targetY - originY) * this.meshHeight;
    const requestedPointerDistance = Math.hypot(targetDeltaX, targetDeltaY);
    this.grabDirection.set(targetDeltaX, targetDeltaY);
    if (this.grabDirection.lengthSq() < 0.0001) this.grabDirection.set(1, 0);
    this.grabDirection.normalize();
    this.activeDirection.copy(this.grabDirection);
    this.grabExtent = this.projectionExtent(
      this.grabOrigin,
      this.activeDirection,
    );
    const maximumPointerDistance = this.peelModelForDepth(
      this.grabExtent,
    ).projection;
    // A nearby target still reaches a complete peel. Extending the target
    // farther than that continues the real drag, translating the detached
    // sticker and pulling its remaining curl taut.
    const fullPointerDistance = Math.max(
      requestedPointerDistance,
      maximumPointerDistance,
    );
    const pointerDistance = clamp(progress, 0, 1) * fullPointerDistance;
    this.setCreaseDepth(this.solveCreaseDepth(pointerDistance));
    const detachedDistance = Math.max(
      0,
      pointerDistance - maximumPointerDistance,
    );
    this.setDetachedDragOffset(
      this.activeDirection.x * detachedDistance,
      this.activeDirection.y * detachedDistance,
    );
    this.state.grabPoint = {
      x: this.grabOrigin.x,
      y: this.grabOrigin.y,
    };
    this.state.pointer = {
      x: this.grabOrigin.x + this.activeDirection.x * pointerDistance,
      y: this.grabOrigin.y + this.activeDirection.y * pointerDistance,
    };
    this.updatePeelUniforms();
    this.renderer.render(this.scene, this.camera);
  }

  setEntranceProgress(progress: number): void {
    if (this.destroyed || !this.artwork) return;
    this.springActive = false;
    this.springVelocity = 0;
    this.detachedExitActive = false;
    this.entranceActive = false;
    this.interactionHintActive = false;
    this.state.dragging = false;
    this.detachedTension = 0;
    this.stickerMesh.position.set(0, 0, 0);
    this.stickerMesh.scale.set(1, 1, 1);
    this.stickerMesh.rotation.z = THREE.MathUtils.degToRad(this.options.tilt);
    this.uniforms.uInteractionHint.value = 0;
    this.setCreaseDepth(0);
    this.state.grabPoint = null;
    this.state.pointer = null;
    this.configureEntranceAxis();
    const completed = this.applyEntranceElapsed(
      clamp(progress, 0, 1) * ENTRANCE_SCALE_DURATION,
    );
    if (completed) this.clearEntrancePose();
    this.updatePeelUniforms();
    this.renderer.render(this.scene, this.camera);
  }

  setBackgroundRemovalEffect(active: boolean): void {
    if (this.destroyed) return;
    this.backgroundRemovalEffectActive = active;
    this.backgroundRemovalEffectElapsed = 0;
    // Background removal intentionally uses the exact same material-bound
    // laser as the sticker entrance instead of maintaining a second look.
    this.configureEntranceAxis();
    this.uniforms.uBackgroundRemovalDistortion.value = active ? 1 : 0;
    if (!this.entranceActive) {
      this.uniforms.uEntranceSweep.value = active ? 0 : -1;
    }
    this.requestRender();
  }

  reappear(): void {
    if (this.destroyed) return;
    this.startEntranceAnimation();
  }

  setRenderScale(scale: number): void {
    if (this.destroyed) return;
    const nextScale = clamp(scale, 1, 6);
    if (Math.abs(nextScale - this.renderScale) < 0.001) return;
    this.renderScale = nextScale;
    this.resize();
  }

  getRenderSnapshot(): StickerRenderSnapshot {
    const origin = this.uniforms.uOrigin.value as THREE.Vector2;
    const direction = this.uniforms.uPeelDir.value as THREE.Vector2;
    return {
      progress: this.uniforms.uPeel.value as number,
      peelDepth: this.uniforms.uPeelDepth.value as number,
      peelRadius: this.uniforms.uRadius.value as number,
      detachedTension: this.uniforms.uDetachedTension.value as number,
      origin: { x: origin.x, y: origin.y },
      direction: { x: direction.x, y: direction.y },
      position: {
        x: this.stickerMesh.position.x,
        y: this.stickerMesh.position.y,
      },
      scale: {
        x: this.stickerMesh.scale.x,
        y: this.stickerMesh.scale.y,
      },
      rotation: this.stickerMesh.rotation.z,
      entranceSweep: this.uniforms.uEntranceSweep.value as number,
      entranceScaleProgress:
        this.uniforms.uEntranceScaleProgress.value as number,
      time: this.uniforms.uTime.value as number,
    };
  }

  setRenderSnapshot(snapshot: StickerRenderSnapshot): void {
    if (this.destroyed || !this.artwork) return;
    this.springActive = false;
    this.detachedExitActive = false;
    this.entranceActive = false;
    this.interactionHintActive = false;
    this.state.dragging = false;
    this.state.progress = snapshot.progress;
    this.creaseDepth = snapshot.peelDepth;
    this.effectivePeelRadius = snapshot.peelRadius;
    this.detachedTension = snapshot.detachedTension;
    this.grabOrigin.set(snapshot.origin.x, snapshot.origin.y);
    this.activeDirection.set(snapshot.direction.x, snapshot.direction.y);
    this.stickerMesh.position.set(
      snapshot.position.x,
      snapshot.position.y,
      0,
    );
    this.stickerMesh.scale.set(snapshot.scale.x, snapshot.scale.y, 1);
    this.stickerMesh.rotation.z = snapshot.rotation;
    this.uniforms.uPeel.value = snapshot.progress;
    this.uniforms.uPeelDepth.value = snapshot.peelDepth;
    this.uniforms.uRadius.value = snapshot.peelRadius;
    this.uniforms.uDetachedTension.value = snapshot.detachedTension;
    (this.uniforms.uOrigin.value as THREE.Vector2).copy(this.grabOrigin);
    (this.uniforms.uPeelDir.value as THREE.Vector2).copy(this.activeDirection);
    this.uniforms.uEntranceSweep.value = snapshot.entranceSweep;
    this.uniforms.uEntranceScaleProgress.value =
      snapshot.entranceScaleProgress;
    this.uniforms.uTime.value = snapshot.time;
    this.renderer.render(this.scene, this.camera);
  }

  resize = (): void => {
    this.resizeInternal(true);
  };

  private resizeObserved = () => {
    this.resizeInternal(false);
  };

  private resizeInternal(forcePublicResize: boolean): void {
    if (this.destroyed) return;
    // CSS transforms are presentation-only. Keeping layout dimensions separate
    // lets export previews supersample without changing the sticker geometry.
    const clientWidth = this.container.clientWidth;
    const clientHeight = this.container.clientHeight;
    const layoutChanged =
      clientWidth !== this.measuredClientWidth ||
      clientHeight !== this.measuredClientHeight;
    this.measuredClientWidth = clientWidth;
    this.measuredClientHeight = clientHeight;
    const width = Math.max(2, Math.round(clientWidth || 640));
    const height = Math.max(2, Math.round(clientHeight || 420));
    const qualityRatio = this.options.quality === "low" ? 1.25 : 2;
    const pixelRatio = Math.min(
      Math.min(window.devicePixelRatio || 1, qualityRatio) * this.renderScale,
      6,
    );
    const surfaceChanged =
      width !== this.renderedWidth ||
      height !== this.renderedHeight ||
      pixelRatio !== this.renderedPixelRatio;
    if (surfaceChanged) {
      this.renderedWidth = width;
      this.renderedHeight = height;
      this.renderedPixelRatio = pixelRatio;
      this.renderer.setPixelRatio(pixelRatio);
      this.renderer.setSize(width, height, false);
      this.viewportHeightPx = height;
      this.viewHeight = 2;
      this.viewWidth = (width / height) * this.viewHeight;
      this.groundShadowMesh.scale.set(
        this.viewWidth * 1.2,
        this.viewHeight * 1.2,
        1,
      );
      this.camera.left = -this.viewWidth / 2;
      this.camera.right = this.viewWidth / 2;
      this.camera.top = this.viewHeight / 2;
      this.camera.bottom = -this.viewHeight / 2;
      this.camera.updateProjectionMatrix();
      const shadowCamera = this.peelShadowLight.shadow
        .camera as THREE.OrthographicCamera;
      const shadowExtent = Math.max(this.viewWidth, this.viewHeight) * 0.9;
      shadowCamera.left = -shadowExtent;
      shadowCamera.right = shadowExtent;
      shadowCamera.top = shadowExtent;
      shadowCamera.bottom = -shadowExtent;
      shadowCamera.near = 0.1;
      shadowCamera.far = 16;
      shadowCamera.updateProjectionMatrix();
    }
    const geometryChanged = this.artwork
      ? this.updateMeshGeometry(
          this.artwork.aspect,
          forcePublicResize || surfaceChanged || layoutChanged,
        )
      : false;
    if (
      !surfaceChanged &&
      !geometryChanged &&
      !layoutChanged &&
      !forcePublicResize
    ) return;
    this.applyOptionsToRenderer();
    // setSize clears the backing buffer. Draw synchronously so the browser
    // never gets a chance to present an empty frame after a resize.
    this.renderer.render(this.scene, this.camera);
  }

  private scheduleResize = () => {
    if (this.destroyed || this.resizeFrameRequest) return;
    this.resizeFrameRequest = requestAnimationFrame(() => {
      this.resizeFrameRequest = 0;
      this.resizeObserved();
    });
  };

  getState(): Readonly<StickerState> {
    return {
      ready: this.state.ready,
      dragging: this.state.dragging,
      progress: this.state.progress,
      grabPoint: this.state.grabPoint ? { ...this.state.grabPoint } : null,
      pointer: this.state.pointer ? { ...this.state.pointer } : null,
    };
  }

  destroy(): void {
    if (this.destroyed) return;
    this.destroyed = true;
    cancelAnimationFrame(this.frameRequest);
    cancelAnimationFrame(this.resizeFrameRequest);
    cancelAnimationFrame(this.hoverFrameRequest);
    this.frameRequest = 0;
    this.resizeFrameRequest = 0;
    this.hoverFrameRequest = 0;
    for (const state of this.preparedSourceStates) {
      const { payload } = takePreparedSourceState(state);
      payload?.texture.dispose();
    }
    this.preparedSourceStates.clear();
    this.cancelPreparedEntrance();
    if (this.sourceRebuildTimer !== null) {
      window.clearTimeout(this.sourceRebuildTimer);
      this.sourceRebuildTimer = null;
    }
    this.resizeObserver?.disconnect();
    this.resizeObserver = null;
    window.removeEventListener("resize", this.scheduleResize);

    const canvas = this.renderer.domElement;
    canvas.removeEventListener("pointerdown", this.onPointerDown);
    canvas.removeEventListener("pointermove", this.onPointerMove);
    canvas.removeEventListener("pointerup", this.onPointerUp);
    canvas.removeEventListener("pointercancel", this.onPointerUp);
    canvas.removeEventListener("lostpointercapture", this.onLostPointerCapture);
    canvas.removeEventListener("pointerleave", this.onPointerLeave);
    canvas.removeEventListener("keydown", this.onKeyDown);
    canvas.removeEventListener("webglcontextlost", this.onContextLost);
    window.removeEventListener("pointerup", this.onWindowPointerEnd, true);
    window.removeEventListener("pointercancel", this.onWindowPointerEnd, true);
    window.removeEventListener("blur", this.onWindowBlur);
    document.removeEventListener("visibilitychange", this.onVisibilityChange);

    this.texture?.dispose();
    this.texture = null;
    this.artwork = null;
    this.source = DEFAULT_SOURCE;
    this.requestedSource = DEFAULT_SOURCE;
    this.options = resolveStickerOptions(undefined, {});
    this.uniforms.uMap.value = null;
    this.uniforms.uPreparedMap.value = null;
    this.geometry.dispose();
    for (const name of Object.keys(this.geometry.attributes)) {
      this.geometry.deleteAttribute(name);
    }
    this.geometry.setIndex(null);
    this.groundShadowGeometry.dispose();
    this.stickerMaterial.dispose();
    this.residueMaterial.dispose();
    this.peelShadowDepthMaterial.dispose();
    this.groundShadowMaterial.dispose();
    this.peelAudio.destroy();
    this.renderer.dispose();
    this.renderer.forceContextLoss();
    canvas.width = 1;
    canvas.height = 1;
    canvas.remove();
  }

  private materialKey() {
    const material = this.options.material;
    const lighting = this.options.lighting;
    return JSON.stringify([
      material.type,
      material.intensity,
      material.scale,
      material.holographicGrain,
      material.seed,
      ...material.holographicColors,
      lighting.direction.x,
      lighting.direction.y,
      lighting.direction.z,
      lighting.intensity,
    ]);
  }

  private createArtworkTexture(
    artwork: PreparedArtwork,
    material = this.options.material,
    lighting = this.options.lighting,
  ) {
    const bakedCanvas = createMaterialPreviewCanvas(
      artwork.canvas,
      artwork.width,
      artwork.height,
      material,
      lighting,
    );
    const nextTexture = new THREE.CanvasTexture(bakedCanvas);
    nextTexture.colorSpace = THREE.SRGBColorSpace;
    nextTexture.minFilter = THREE.LinearMipmapLinearFilter;
    nextTexture.magFilter = THREE.LinearFilter;
    nextTexture.generateMipmaps = true;
    nextTexture.anisotropy = Math.min(
      8,
      this.renderer.capabilities.getMaxAnisotropy(),
    );
    nextTexture.needsUpdate = true;
    return nextTexture;
  }

  private refreshMaterialTexture() {
    if (!this.artwork) return;
    const previousTexture = this.texture;
    const nextTexture = this.createArtworkTexture(this.artwork);
    this.texture = nextTexture;
    this.uniforms.uMap.value = nextTexture;
    if (this.uniforms.uPreparedMap.value === previousTexture) {
      this.uniforms.uPreparedMap.value = nextTexture;
    }
    this.uniforms.uMaterialBaked.value = 1;
    previousTexture?.dispose();
  }

  private cancelPreparedEntrance() {
    const prepared = this.preparedEntrance;
    this.preparedEntrance = null;
    if (prepared) prepared.texture.dispose();
    this.uniforms.uPreparedMix.value = 0;
    this.uniforms.uPreEntranceProgress.value = 0;
    this.uniforms.uPreparedMap.value = this.texture;
  }

  private applyArtwork(
    artwork: PreparedArtwork,
    nextTexture = this.createArtworkTexture(artwork),
  ) {
    this.artwork = artwork;
    const previousTexture = this.texture;
    this.texture = nextTexture;
    this.uniforms.uMap.value = nextTexture;
    this.uniforms.uPreparedMap.value = nextTexture;
    this.uniforms.uPreparedMix.value = 0;
    this.uniforms.uMaterialBaked.value = 1;
    this.uniforms.uPreEntranceProgress.value = 0;
    (this.uniforms.uTexel.value as THREE.Vector2).set(
      1 / artwork.width,
      1 / artwork.height,
    );
    this.updateMeshGeometry(artwork.aspect);
    this.applyOptionsToRenderer();
    this.reset();
    this.state.ready = true;
    previousTexture?.dispose();
    this.emit("ready", {
      width: artwork.width,
      height: artwork.height,
      hasTransparency: artwork.hasTransparency,
    });
  }

  private updateMeshGeometry(
    aspect: number,
    resetUnchangedPeel = false,
  ) {
    const worldUnitsPerPixel =
      this.viewHeight / Math.max(1, this.viewportHeightPx);
    let width: number;
    let height: number;
    if (this.options.display.width > 0 && this.options.display.height > 0) {
      width = this.options.display.width * worldUnitsPerPixel;
      height = this.options.display.height * worldUnitsPerPixel;
    } else {
      const maxWidth = Math.min(
        this.viewWidth * 0.78,
        MAX_STICKER_WIDTH_PX * worldUnitsPerPixel,
      );
      const maxHeight = Math.min(
        this.viewHeight * 0.58,
        MAX_STICKER_HEIGHT_PX * worldUnitsPerPixel,
      );
      width = maxWidth;
      height = width / aspect;
      if (height > maxHeight) {
        height = maxHeight;
        width = height * aspect;
      }
    }
    const nextMeshWidth =
      this.options.display.width > 0
        ? Math.max(0.001, width)
        : Math.max(0.34, width);
    const nextMeshHeight =
      this.options.display.height > 0 ? Math.max(0.001, height) : Math.max(0.25, height);

    const longSegments =
      this.options.quality === "high"
        ? 240
        : this.options.quality === "medium"
          ? 160
          : 96;
    const segmentsX = clamp(Math.round(longSegments), 64, 256);
    const segmentsY = clamp(
      Math.round(longSegments / Math.max(aspect, 0.35)),
      56,
      192,
    );
    const topologyChanged =
      segmentsX !== this.geometrySegmentsX ||
      segmentsY !== this.geometrySegmentsY;
    const dimensionsChanged =
      Math.abs(nextMeshWidth - this.geometryWidth) > 0.000001 ||
      Math.abs(nextMeshHeight - this.geometryHeight) > 0.000001;
    if (!topologyChanged && !dimensionsChanged) {
      if (resetUnchangedPeel) this.resetGeometryPeelState();
      return false;
    }

    this.meshWidth = nextMeshWidth;
    this.meshHeight = nextMeshHeight;
    if (topologyChanged) {
      const nextGeometry = new THREE.PlaneGeometry(
        this.meshWidth,
        this.meshHeight,
        segmentsX,
        segmentsY,
      );
      const previousGeometry = this.geometry;
      this.geometry = nextGeometry;
      this.stickerMesh.geometry = nextGeometry;
      this.residueMesh.geometry = nextGeometry;
      previousGeometry.dispose();
      this.geometrySegmentsX = segmentsX;
      this.geometrySegmentsY = segmentsY;
    } else {
      const positions = this.geometry.attributes.position;
      let vertex = 0;
      for (let row = 0; row <= segmentsY; row += 1) {
        const y = (0.5 - row / segmentsY) * this.meshHeight;
        for (let column = 0; column <= segmentsX; column += 1) {
          const x = (column / segmentsX - 0.5) * this.meshWidth;
          positions.setXYZ(vertex, x, y, 0);
          vertex += 1;
        }
      }
      positions.needsUpdate = true;
      this.geometry.computeBoundingBox();
      this.geometry.computeBoundingSphere();
    }
    this.geometryWidth = this.meshWidth;
    this.geometryHeight = this.meshHeight;
    this.resetGeometryPeelState();
    return true;
  }

  private resetGeometryPeelState() {
    (this.uniforms.uMeshSize.value as THREE.Vector2).set(
      this.meshWidth,
      this.meshHeight,
    );
    this.grabOrigin.set(-this.meshWidth / 2, 0);
    this.grabDirection.set(1, 0);
    this.activeDirection.copy(this.grabDirection);
    this.grabExtent = this.meshWidth;
    this.setCreaseDepth(0);
    this.updatePeelUniforms();
  }

  private applyOptionsToRenderer() {
    const angle = THREE.MathUtils.degToRad(this.options.tilt);
    this.stickerMesh.rotation.z = angle;
    this.residueMesh.rotation.z = angle;

    this.uniforms.uBackColor.value = colorFrom(
      this.options.back.color,
      "#f7f5f2",
    );
    this.uniforms.uEdgeBevelWidth.value = clamp(
      this.options.edge.width,
      0.5,
      6,
    );
    this.uniforms.uEdgeFinishStrength.value = clamp(
      this.options.edge.strength,
      0,
      1,
    );
    this.uniforms.uGloss.value = clamp(this.options.back.gloss, 0, 1);
    this.uniforms.uRoughness.value = clamp(this.options.back.roughness, 0, 1);
    this.uniforms.uMaterialType.value = stickerMaterialTypeIndex(
      this.options.material.type,
    );
    this.uniforms.uMaterialIntensity.value = clamp(
      this.options.material.intensity,
      0,
      1,
    );
    this.uniforms.uMaterialScale.value = clamp(
      this.options.material.scale,
      0.2,
      4,
    );
    this.uniforms.uHolographicGrain.value = clamp(
      this.options.material.holographicGrain,
      0,
      1,
    );
    this.uniforms.uMaterialSeed.value = this.options.material.seed;
    this.uniforms.uHolographicColorA.value = colorFrom(
      this.options.material.holographicColors[0],
      "#f2a7c5",
    );
    this.uniforms.uHolographicColorB.value = colorFrom(
      this.options.material.holographicColors[1],
      "#8edfd5",
    );
    this.uniforms.uHolographicColorC.value = colorFrom(
      this.options.material.holographicColors[2],
      "#9db4ea",
    );
    this.uniforms.uWind.value = Math.max(0, this.options.wind);
    const lightDirection = this.uniforms.uLightDirection.value as THREE.Vector3;
    lightDirection.set(
      this.options.lighting.direction.x,
      this.options.lighting.direction.y,
      Math.max(0.001, this.options.lighting.direction.z),
    );
    if (lightDirection.lengthSq() < 0.0001) {
      lightDirection.set(-0.38, 0.52, 0.76);
    } else {
      lightDirection.normalize();
    }
    const lightIntensity = clamp(this.options.lighting.intensity, 0, 1.5);
    const ambientLight = clamp(this.options.lighting.ambient, 0, 1);
    const lightSoftness = clamp(this.options.lighting.softness, 0, 1);
    this.uniforms.uLightIntensity.value = lightIntensity;
    this.uniforms.uAmbientLight.value = ambientLight;
    this.uniforms.uLightSoftness.value = lightSoftness;

    const customSoundSource = this.options.sound.src.trim();
    this.peelAudio.configure({
      enabled: this.options.sound.enabled,
      src: customSoundSource || DEFAULT_PEEL_SOUND_URL,
      volume: this.options.sound.volume,
      useBuiltInProfile: !customSoundSource,
    });

    const rawAngle = this.options.peel.maxAngle;
    const angleInRadians =
      rawAngle > Math.PI * 2 ? THREE.MathUtils.degToRad(rawAngle) : rawAngle;
    this.uniforms.uMaxAngle.value = clamp(
      angleInRadians,
      MIN_CURL_ANGLE,
      MAX_CURL_ANGLE,
    );
    const radius = this.options.peel.radius;
    const rect = this.container.getBoundingClientRect();
    const configuredRadius =
      radius <= 1
        ? Math.max(0.008, Math.min(this.meshWidth, this.meshHeight) * radius)
        : Math.max(0.008, (radius / Math.max(rect.height, 1)) * this.viewHeight);
    this.basePeelRadius =
      configuredRadius *
      THREE.MathUtils.lerp(
        0.82,
        1.16,
        clamp(this.options.peel.stiffness, 0, 1),
      );
    this.residueMesh.visible = this.options.peel.residue;
    this.uniforms.uSurfaceShadowEnabled.value =
      this.options.peel.surfaceShadow ? 1 : 0;
    this.setCreaseDepth(this.creaseDepth);

    this.uniforms.uShadowColor.value = colorFrom(
      this.options.shadow.color,
      "#191823",
    );
    const shadowContrast =
      (0.45 + lightIntensity * 0.75) * (1 - ambientLight * 0.35);
    const effectiveShadowOpacity = clamp(
      this.options.shadow.opacity * shadowContrast,
      0,
      0.9,
    );
    this.uniforms.uShadowOpacity.value = effectiveShadowOpacity;
    this.groundShadowMaterial.color.copy(
      colorFrom(this.options.shadow.color, "#191823"),
    );
    this.groundShadowMaterial.opacity = effectiveShadowOpacity;
    const unscaledDisplayWidth =
      (this.meshWidth / Math.max(this.viewWidth, 0.001)) *
      Math.max(this.renderer.domElement.clientWidth, 1);
    const textureScale = this.artwork
      ? this.artwork.width / Math.max(unscaledDisplayWidth, 1)
      : 1;
    this.uniforms.uEdgeFinishScale.value = clamp(textureScale, 0.75, 8);
    this.uniforms.uInteractionHintRadius.value = this.artwork
      ? clamp(
          this.options.peel.grabWidth * textureScale,
          3,
          Math.min(this.artwork.width, this.artwork.height) * 0.13,
        )
      : 3;
    const softnessScale = THREE.MathUtils.lerp(0.55, 1.3, lightSoftness);
    this.uniforms.uShadowBlur.value =
      Math.max(0, this.options.shadow.blur) *
      textureScale *
      0.34 *
      softnessScale;
    this.uniforms.uShadowDistance.value =
      (Math.max(0, this.options.shadow.distance) /
        Math.max(rect.width || 1, 1)) *
      this.viewWidth;
    const shadowDirection = this.uniforms.uShadowDirection.value as THREE.Vector2;
    shadowDirection.set(-lightDirection.x, -lightDirection.y);
    if (shadowDirection.lengthSq() < 0.0001) {
      const fallbackAngle = THREE.MathUtils.degToRad(this.options.shadow.angle);
      shadowDirection.set(
        Math.cos(fallbackAngle),
        -Math.sin(fallbackAngle),
      );
    }
    shadowDirection.normalize();
    const shadowDistance = this.uniforms.uShadowDistance.value as number;
    const lightOffset = 1.6 + shadowDistance * 34;
    this.peelShadowLight.position.set(
      lightDirection.x * lightOffset,
      lightDirection.y * lightOffset,
      Math.max(0.8, lightDirection.z * lightOffset),
    );
    this.peelShadowTarget.position.set(0, 0, 0);
    // Use the configured CSS-like blur as the kernel size. Previously every
    // shadow was squeezed into the same tiny 1-7 texel range.
    this.peelShadowLight.shadow.radius = clamp(
      this.options.shadow.blur *
        THREE.MathUtils.lerp(0.42, 0.72, lightSoftness),
      1,
      56,
    );
    const shadowMapSize = this.options.quality === "high" ? 2048 : 1024;
    this.peelShadowLight.shadow.mapSize.set(shadowMapSize, shadowMapSize);
    this.peelShadowLight.shadow.needsUpdate = true;
  }

  private updatePeelUniforms() {
    this.uniforms.uPeel.value = this.state.progress;
    this.uniforms.uPeelDepth.value = this.creaseDepth;
    this.uniforms.uDetachedTension.value = this.detachedTension;
    this.uniforms.uRadius.value = this.effectivePeelRadius;
    (this.uniforms.uOrigin.value as THREE.Vector2).copy(this.grabOrigin);
    (this.uniforms.uPeelDir.value as THREE.Vector2).copy(this.activeDirection);
    const percent = Math.round(clamp(this.state.progress, 0, 1) * 100);
    this.renderer.domElement.setAttribute("aria-valuenow", String(percent));
    this.renderer.domElement.setAttribute("aria-valuetext", `${percent}% peeled`);
  }

  private projectedGrabDistance(
    depth: number,
    radius: number,
    maxAngle = this.uniforms.uMaxAngle.value as number,
  ) {
    if (depth <= 0) return 0;
    const safeRadius = Math.max(radius, 0.001);
    const angle = Math.min(depth / safeRadius, maxAngle);
    const arcLength = safeRadius * maxAngle;
    let projected = -safeRadius * Math.sin(angle);
    if (depth > arcLength) {
      projected -= (depth - arcLength) * Math.cos(maxAngle);
    }
    return Math.max(0, depth + projected);
  }

  private peelModelForDepth(depth: number) {
    const safeDepth = clamp(depth, 0, Math.max(this.grabExtent, 0.001));
    if (safeDepth <= 0.000001) {
      return {
        depth: 0,
        radius: this.basePeelRadius,
        projection: 0,
      };
    }

    const baseProjection = this.projectedGrabDistance(
      safeDepth,
      this.basePeelRadius,
    );
    const minimumProjection = safeDepth / MAX_FRONT_TO_POINTER_RATIO;
    if (baseProjection >= minimumProjection) {
      return {
        depth: safeDepth,
        radius: this.basePeelRadius,
        projection: baseProjection,
      };
    }

    const adaptiveRadius = safeDepth / MIN_CURL_ANGLE;
    return {
      depth: safeDepth,
      radius: adaptiveRadius,
      projection: this.projectedGrabDistance(safeDepth, adaptiveRadius),
    };
  }

  private setCreaseDepth(depth: number) {
    const model = this.peelModelForDepth(depth);
    this.creaseDepth = model.depth;
    this.effectivePeelRadius = model.radius;
    this.grabProjection = model.projection;
    this.state.progress = clamp(
      this.creaseDepth / Math.max(this.grabExtent, 0.001),
      0,
      1,
    );
  }

  private solveCreaseDepth(pointerDistance: number) {
    const target = Math.max(0, pointerDistance);
    const maximum = this.peelModelForDepth(this.grabExtent);
    if (target >= maximum.projection) return maximum.depth;
    if (target <= 0.000001) return 0;

    let low = 0;
    let high = this.grabExtent;
    for (let iteration = 0; iteration < 16; iteration += 1) {
      const middle = (low + high) * 0.5;
      if (this.peelModelForDepth(middle).projection < target) {
        low = middle;
      } else {
        high = middle;
      }
    }
    return (low + high) * 0.5;
  }

  private setDetachedDragOffset(localX: number, localY: number) {
    const angle = THREE.MathUtils.degToRad(this.options.tilt);
    const cosine = Math.cos(angle);
    const sine = Math.sin(angle);
    const pullDistance = Math.hypot(localX, localY);
    const tensionDistance = Math.max(this.grabExtent * 0.45, 0.12);
    const linearTension = clamp(pullDistance / tensionDistance, 0, 1);
    this.detachedTension = linearTension * linearTension * (3 - 2 * linearTension);
    const flatteningCompensation =
      this.grabProjection - this.grabExtent * 2;
    const compensatedX =
      localX +
      this.activeDirection.x * flatteningCompensation * this.detachedTension;
    const compensatedY =
      localY +
      this.activeDirection.y * flatteningCompensation * this.detachedTension;
    this.stickerMesh.position.set(
      compensatedX * cosine - compensatedY * sine,
      compensatedX * sine + compensatedY * cosine,
      0,
    );
  }

  private screenToLocal(clientX: number, clientY: number) {
    const rect = this.renderer.domElement.getBoundingClientRect();
    const normalizedX = ((clientX - rect.left) / Math.max(rect.width, 1)) * 2 - 1;
    const normalizedY = 1 - ((clientY - rect.top) / Math.max(rect.height, 1)) * 2;
    const worldX = normalizedX * (this.viewWidth / 2);
    const worldY = normalizedY * (this.viewHeight / 2);
    const angle = -THREE.MathUtils.degToRad(this.options.tilt);
    const cosine = Math.cos(angle);
    const sine = Math.sin(angle);
    return new THREE.Vector2(
      worldX * cosine - worldY * sine,
      worldX * sine + worldY * cosine,
    );
  }

  private sampleAlpha(x: number, y: number) {
    if (!this.artwork) return 0;
    const pixelX = clamp(Math.round(x), 0, this.artwork.width - 1);
    const pixelY = clamp(Math.round(y), 0, this.artwork.height - 1);
    return this.artwork.alpha[pixelY * this.artwork.width + pixelX] / 255;
  }

  private sampleExterior(x: number, y: number) {
    if (!this.artwork) return false;
    const pixelX = Math.round(x);
    const pixelY = Math.round(y);
    if (
      pixelX < 0 ||
      pixelX >= this.artwork.width ||
      pixelY < 0 ||
      pixelY >= this.artwork.height
    ) return true;
    return this.artwork.exteriorAlpha[pixelY * this.artwork.width + pixelX] === 1;
  }

  private hitEdge(local: THREE.Vector2): EdgeHit | null {
    if (!this.artwork) return null;
    const u = local.x / this.meshWidth + 0.5;
    const v = local.y / this.meshHeight + 0.5;
    if (u < -0.04 || u > 1.04 || v < -0.04 || v > 1.04) return null;
    const pixelX = u * (this.artwork.width - 1);
    const pixelY = (1 - v) * (this.artwork.height - 1);
    const unscaledDisplayedWidth =
      (this.meshWidth / Math.max(this.viewWidth, 0.001)) *
      this.renderer.domElement.clientWidth;
    const pixelsPerCss =
      this.artwork.width / Math.max(unscaledDisplayedWidth, 1);
    const radius = clamp(
      this.options.peel.grabWidth * pixelsPerCss,
      3,
      Math.min(this.artwork.width, this.artwork.height) * 0.13,
    );
    const searchRadius = Math.ceil(radius);
    const minimumX = Math.max(0, Math.floor(pixelX - searchRadius));
    const maximumX = Math.min(
      this.artwork.width - 1,
      Math.ceil(pixelX + searchRadius),
    );
    const minimumY = Math.max(0, Math.floor(pixelY - searchRadius));
    const maximumY = Math.min(
      this.artwork.height - 1,
      Math.ceil(pixelY + searchRadius),
    );
    let nearestX = -1;
    let nearestY = -1;
    let nearestDistanceSq = radius * radius + 1;
    for (let candidateY = minimumY; candidateY <= maximumY; candidateY += 1) {
      for (let candidateX = minimumX; candidateX <= maximumX; candidateX += 1) {
        const offsetX = candidateX - pixelX;
        const offsetY = candidateY - pixelY;
        const distanceSq = offsetX * offsetX + offsetY * offsetY;
        if (distanceSq >= nearestDistanceSq || distanceSq > radius * radius) {
          continue;
        }
        const alpha = this.sampleAlpha(candidateX, candidateY);
        if (alpha < 0.1) continue;
        const isOuterBoundary =
          this.sampleExterior(candidateX - 1, candidateY) ||
          this.sampleExterior(candidateX + 1, candidateY) ||
          this.sampleExterior(candidateX, candidateY - 1) ||
          this.sampleExterior(candidateX, candidateY + 1);
        if (!isOuterBoundary) continue;
        nearestX = candidateX;
        nearestY = candidateY;
        nearestDistanceSq = distanceSq;
      }
    }
    if (nearestX < 0 || nearestY < 0) return null;

    const edgeLocal = new THREE.Vector2(
      (nearestX / Math.max(this.artwork.width - 1, 1) - 0.5) * this.meshWidth,
      (0.5 - nearestY / Math.max(this.artwork.height - 1, 1)) * this.meshHeight,
    );
    const delta = clamp(radius * 0.14, 1.5, 4.5);
    const gradient = new THREE.Vector2(
      this.sampleAlpha(nearestX + delta, nearestY) -
        this.sampleAlpha(nearestX - delta, nearestY),
      -(
        this.sampleAlpha(nearestX, nearestY + delta) -
        this.sampleAlpha(nearestX, nearestY - delta)
      ),
    );
    if (gradient.lengthSq() < 0.008) gradient.set(-edgeLocal.x, -edgeLocal.y);
    if (gradient.lengthSq() < 0.0001) gradient.set(1, 0);
    gradient.normalize();
    return { local: edgeLocal, inward: gradient };
  }

  private projectionExtent(origin: THREE.Vector2, direction: THREE.Vector2) {
    if (!this.artwork) return Math.max(this.meshHeight * 0.35, this.meshWidth);
    let maximum = this.meshHeight * 0.35;
    for (let index = 0; index < this.artwork.support.length; index += 2) {
      const localX = (this.artwork.support[index] - 0.5) * this.meshWidth;
      const localY = (0.5 - this.artwork.support[index + 1]) * this.meshHeight;
      maximum = Math.max(
        maximum,
        (localX - origin.x) * direction.x +
          (localY - origin.y) * direction.y,
      );
    }
    return Math.max(this.meshHeight * 0.35, maximum + this.meshHeight * 0.025);
  }

  private onPointerDown = (event: PointerEvent) => {
    if (
      this.destroyed ||
      !this.state.ready ||
      this.detachedExitActive ||
      this.entranceActive ||
      event.button !== 0
    ) return;
    if (this.hoverFrameRequest) {
      cancelAnimationFrame(this.hoverFrameRequest);
      this.hoverFrameRequest = 0;
    }
    const local = this.screenToLocal(event.clientX, event.clientY);
    const hit = this.hitEdge(local);
    if (!hit) {
      this.startInteractionHint();
      return;
    }
    this.interactionHintActive = false;
    this.interactionHintElapsed = 0;
    this.uniforms.uInteractionHint.value = 0;
    event.preventDefault();
    this.renderer.domElement.focus({ preventScroll: true });
    this.renderer.domElement.setPointerCapture(event.pointerId);
    this.pointerId = event.pointerId;
    this.grabOrigin.copy(hit.local);
    this.grabStart.copy(hit.local);
    this.grabDirection.copy(hit.inward);
    this.activeDirection.copy(hit.inward);
    this.grabExtent = this.projectionExtent(
      this.grabOrigin,
      this.grabDirection,
    );
    this.setCreaseDepth(0);
    this.springActive = false;
    this.springVelocity = 0;
    this.springTargetDepth = 0;
    this.dragDetached = false;
    this.state.dragging = true;
    this.state.grabPoint = { x: hit.local.x, y: hit.local.y };
    this.state.pointer = { x: local.x, y: local.y };
    this.renderer.domElement.style.cursor = "grabbing";
    this.peelAudio.unlock();
    this.peelAudio.begin(this.state.progress, event.timeStamp);
    this.updatePeelUniforms();
    this.emit("peelstart", {
      amount: this.state.progress,
      progress: this.state.progress,
      origin: this.state.grabPoint,
    });
    this.requestRender();
  };

  private onPointerMove = (event: PointerEvent) => {
    if (this.destroyed || !this.state.ready) return;
    if (
      this.state.dragging &&
      event.pointerId === this.pointerId &&
      event.buttons === 0
    ) {
      this.finishPointerDrag(event.timeStamp);
      return;
    }
    if (!this.state.dragging || event.pointerId !== this.pointerId) {
      this.hoverClientX = event.clientX;
      this.hoverClientY = event.clientY;
      if (!this.hoverFrameRequest) {
        this.hoverFrameRequest = requestAnimationFrame(
          this.updateHoverCursor,
        );
      }
      return;
    }

    event.preventDefault();
    const local = this.screenToLocal(event.clientX, event.clientY);
    const drag = local.clone().sub(this.grabStart);
    const distance = drag.length();
    let pointerDistance = 0;
    let shouldReturnFromInvalidDirection = false;
    if (this.dragDetached) {
      const returnDirection =
        distance > DIRECTION_DEAD_ZONE
          ? drag.clone().normalize()
          : this.grabDirection;
      if (
        returnDirection.dot(this.grabDirection) >= OUTWARD_DIRECTION_LIMIT
      ) {
        this.activeDirection.copy(returnDirection);
        this.grabExtent = this.projectionExtent(
          this.grabOrigin,
          this.activeDirection,
        );
        const maximumPointerDistance = this.peelModelForDepth(
          this.grabExtent,
        ).projection;
        // Crossing back inside the fully peeled front means the user is
        // deliberately retracing the peel. Hand control back to the ordinary
        // spring path so the sticker can reattach continuously.
        if (distance < maximumPointerDistance) {
          this.dragDetached = false;
        }
      }
    }
    if (this.dragDetached) {
      // Crossing onto the invalid side does not count as retracing the peel.
      // Keep carrying the detached mesh there instead of starting the return
      // spring and leaving its translation behind.
      const maximumPointerDistance = this.peelModelForDepth(
        this.grabExtent,
      ).projection;
      this.springActive = false;
      this.springVelocity = 0;
      this.springTargetDepth = this.grabExtent;
      this.setCreaseDepth(this.grabExtent);
      this.setDetachedDragOffset(
        drag.x - this.activeDirection.x * maximumPointerDistance,
        drag.y - this.activeDirection.y * maximumPointerDistance,
      );
    } else {
      if (distance > DIRECTION_DEAD_ZONE) {
        const candidate = drag.clone().normalize();
        if (candidate.dot(this.grabDirection) >= OUTWARD_DIRECTION_LIMIT) {
          this.activeDirection.copy(candidate);
          pointerDistance = distance;
        } else {
          // Keep the last valid peel direction and let the lifted portion settle
          // back continuously. Setting pointerDistance to zero here used to make
          // a deeply peeled sticker become flat in a single frame.
          shouldReturnFromInvalidDirection = true;
        }
      } else {
        this.activeDirection.copy(this.grabDirection);
      }
      this.grabExtent = this.projectionExtent(
        this.grabOrigin,
        this.activeDirection,
      );
      if (shouldReturnFromInvalidDirection) {
        if (!this.springActive) {
          this.springActive = true;
          this.springVelocity = 0;
        }
        this.springTargetDepth = 0;
      } else {
        const maximumPointerDistance = this.peelModelForDepth(
          this.grabExtent,
        ).projection;
        const targetDepth = this.solveCreaseDepth(pointerDistance);
        const returnDistance = this.creaseDepth - targetDepth;
        const shouldSmoothReturn =
          returnDistance > this.grabExtent * MAX_DIRECT_RETURN_STEP_RATIO ||
          (this.springActive && targetDepth < this.creaseDepth);
        if (shouldSmoothReturn) {
          if (!this.springActive) {
            this.springActive = true;
            this.springVelocity = 0;
          }
          this.springTargetDepth = targetDepth;
        } else {
          this.springActive = false;
          this.springVelocity = 0;
          this.springTargetDepth = targetDepth;
          this.setCreaseDepth(targetDepth);
        }
        // Once every point has crossed the crease, the remaining pointer travel
        // moves the detached sticker instead of being discarded at progress 1.
        // Converting from sticker-local space keeps the grabbed point under the
        // pointer even when the sticker has a configured tilt.
        const detachedDistance = Math.max(
          0,
          pointerDistance - maximumPointerDistance,
        );
        this.setDetachedDragOffset(
          this.activeDirection.x * detachedDistance,
          this.activeDirection.y * detachedDistance,
        );
        if (this.state.progress >= 1 - Number.EPSILON) {
          this.dragDetached = true;
        }
      }
    }
    this.peelAudio.update(
      this.state.progress,
      event.timeStamp,
      this.activeDirection.x,
    );
    this.state.pointer = { x: local.x, y: local.y };
    this.updatePeelUniforms();
    this.emit("peelchange", {
      amount: this.state.progress,
      progress: this.state.progress,
      direction: { x: this.activeDirection.x, y: this.activeDirection.y },
    });
    this.requestRender();
  };

  private onPointerUp = (event: PointerEvent) => {
    if (!this.state.dragging || event.pointerId !== this.pointerId) return;
    this.finishPointerDrag(event.timeStamp);
  };

  private onWindowPointerEnd = (event: PointerEvent) => {
    if (!this.state.dragging || event.pointerId !== this.pointerId) return;
    this.finishPointerDrag(event.timeStamp);
  };

  private onLostPointerCapture = (event: PointerEvent) => {
    if (!this.state.dragging || event.pointerId !== this.pointerId) return;
    this.finishPointerDrag(event.timeStamp);
  };

  private onWindowBlur = () => {
    this.finishPointerDrag(performance.now());
  };

  private onVisibilityChange = () => {
    if (document.visibilityState === "hidden") {
      this.finishPointerDrag(performance.now());
    }
  };

  private finishPointerDrag(timeStamp: number) {
    if (!this.state.dragging) return;
    const activePointerId = this.pointerId;
    this.pointerId = null;
    this.state.dragging = false;
    if (
      activePointerId !== null &&
      this.renderer.domElement.hasPointerCapture(activePointerId)
    ) {
      this.renderer.domElement.releasePointerCapture(activePointerId);
    }
    this.renderer.domElement.style.cursor = "grab";
    const release = this.options.peel.release;
    const releaseProgress = this.springActive
      ? Math.min(
          this.state.progress,
          clamp(
            this.springTargetDepth / Math.max(this.grabExtent, 0.001),
            0,
            1,
          ),
        )
      : this.state.progress;
    const shouldDetach =
      (release === "snap" && releaseProgress >= SNAP_DETACH_THRESHOLD) ||
      (release === "snap" &&
        this.options.peel.detachThreshold < SNAP_DETACH_THRESHOLD &&
        releaseProgress >=
          clamp(this.options.peel.detachThreshold, 0.1, SNAP_DETACH_THRESHOLD));
    if (shouldDetach) {
      this.setCreaseDepth(this.grabExtent);
      this.state.pointer = {
        x: this.grabOrigin.x + this.activeDirection.x * this.grabProjection,
        y: this.grabOrigin.y + this.activeDirection.y * this.grabProjection,
      };
      this.updatePeelUniforms();
      this.peelAudio.update(
        this.state.progress,
        timeStamp,
        this.activeDirection.x,
      );
    }
    this.peelAudio.end(this.state.progress);
    const shouldReset =
      release === "reset" || (release === "snap" && !shouldDetach);
    const reducedMotion = this.reducedMotionQuery.matches;
    if (!shouldReset) {
      this.springActive = false;
      this.springVelocity = 0;
      this.springTargetDepth = this.creaseDepth;
    }
    if (shouldReset && !reducedMotion) {
      this.springActive = true;
      this.springVelocity = 0;
      this.springTargetDepth = 0;
    }
    this.emit("peelend", {
      amount: this.state.progress,
      progress: this.state.progress,
      willReset: shouldReset,
    });
    if (shouldDetach) {
      if (reducedMotion) {
        this.emit("detachcomplete", { progress: 1 });
        if (this.destroyed) return;
        this.reset();
        return;
      }
      this.detachedExitActive = true;
      this.detachedExitElapsed = 0;
      this.detachedExitSpin = this.activeDirection.x >= 0 ? -0.42 : 0.42;
    }
    if (shouldReset && reducedMotion) {
      this.reset();
      return;
    }
    this.requestRender();
  }

  private onPointerLeave = () => {
    if (this.state.dragging) return;
    if (this.hoverFrameRequest) {
      cancelAnimationFrame(this.hoverFrameRequest);
      this.hoverFrameRequest = 0;
    }
    if (this.renderer.domElement.style.cursor !== "default") {
      this.renderer.domElement.style.cursor = "default";
    }
  };

  private updateHoverCursor = () => {
    this.hoverFrameRequest = 0;
    if (this.destroyed || this.state.dragging) return;
    const cursor = this.hitEdge(
      this.screenToLocal(this.hoverClientX, this.hoverClientY),
    )
      ? "grab"
      : "default";
    if (this.renderer.domElement.style.cursor !== cursor) {
      this.renderer.domElement.style.cursor = cursor;
    }
  };

  private onKeyDown = (event: KeyboardEvent) => {
    if (!this.state.ready) return;
    const increase = event.key === "ArrowUp" || event.key === "ArrowRight";
    const decrease = event.key === "ArrowDown" || event.key === "ArrowLeft";
    if (!increase && !decrease && event.key !== " ") return;
    event.preventDefault();
    this.peelAudio.unlock();
    if (event.key === " ") {
      this.reset();
      return;
    }
    this.grabOrigin.set(-this.meshWidth / 2, 0);
    this.activeDirection.set(1, 0);
    this.grabDirection.copy(this.activeDirection);
    this.grabExtent = this.meshWidth;
    const previousProgress = this.state.progress;
    const nextProgress = clamp(
      previousProgress + (increase ? 0.08 : -0.08),
      0,
      1,
    );
    this.setCreaseDepth(nextProgress * this.grabExtent);
    this.peelAudio.begin(previousProgress, event.timeStamp - 72);
    this.peelAudio.update(
      this.state.progress,
      event.timeStamp,
      this.activeDirection.x,
    );
    this.peelAudio.end(this.state.progress);
    this.state.pointer = {
      x: this.grabOrigin.x + this.activeDirection.x * this.grabProjection,
      y: this.grabOrigin.y + this.activeDirection.y * this.grabProjection,
    };
    this.updatePeelUniforms();
    this.emit("peelchange", {
      amount: this.state.progress,
      progress: this.state.progress,
    });
    this.requestRender();
  };

  private onContextLost = (event: Event) => {
    event.preventDefault();
    this.emit("error", {
      message: "The WebGL context was lost. Reload the page to restore the sticker.",
    });
  };

  private requestRender() {
    if (this.destroyed || this.frameRequest) return;
    this.frameRequest = requestAnimationFrame(this.renderFrame);
  }

  private startInteractionHint() {
    this.interactionHintActive = true;
    this.interactionHintElapsed = 0;
    this.uniforms.uInteractionHint.value = 1;
    this.requestRender();
  }

  private configureEntranceAxis() {
    this.entranceAxis.set(
      this.meshWidth >= this.meshHeight ? 1 : 0,
      this.meshWidth >= this.meshHeight ? 0 : -1,
    );
    (this.uniforms.uEntranceAxis.value as THREE.Vector2).copy(
      this.entranceAxis,
    );
  }

  private applyEntranceElapsed(elapsed: number) {
    const scaleProgress = clamp(elapsed / ENTRANCE_SCALE_DURATION, 0, 1);
    this.uniforms.uEntranceScaleProgress.value = scaleProgress;
    const sweepProgress = clamp(
      (elapsed - ENTRANCE_SWEEP_DELAY) / ENTRANCE_SWEEP_DURATION,
      0,
      1,
    );
    this.uniforms.uEntranceSweep.value =
      elapsed < ENTRANCE_SWEEP_DELAY ? -1 : sweepProgress;
    return scaleProgress >= 1 && sweepProgress >= 1;
  }

  private clearEntrancePose() {
    this.uniforms.uEntranceScaleProgress.value = -1;
    this.uniforms.uEntranceSweep.value = -1;
  }

  private startEntranceAnimation() {
    this.reset();
    this.peelAudio.playReappear();
    this.entranceActive = true;
    this.entranceElapsed = 0;
    this.configureEntranceAxis();
    this.applyLaserEffectSettings();
    this.applyEntranceElapsed(0);
    this.requestRender();
  }

  private applyLaserEffectSettings() {
    const settings = getLaserEffectSettings();
    this.uniforms.uLaserCoreWidth.value = settings.coreWidth;
    this.uniforms.uLaserBandWidth.value = settings.bandWidth;
    this.uniforms.uLaserBandOpacity.value = settings.bandOpacity;
    this.uniforms.uLaserBrightness.value = settings.brightness;
    this.uniforms.uLaserHighlightIntensity.value =
      settings.highlightIntensity;
    this.uniforms.uRemovalDistortionRange.value = settings.distortionRange;
    this.uniforms.uRemovalDistortionStrength.value =
      settings.distortionStrength;
    this.uniforms.uRemovalRippleDensity.value = settings.rippleDensity;
    this.uniforms.uRemovalRippleSpeed.value = settings.rippleSpeed;
  }

  private renderFrame = (time: number) => {
    this.frameRequest = 0;
    if (this.destroyed) return;
    const delta = this.lastFrameTime
      ? Math.min((time - this.lastFrameTime) / 1000, 1 / 20)
      : 1 / 60;
    this.lastFrameTime = time;

    const reducedMotion = this.reducedMotionQuery.matches;
    if (this.springActive && reducedMotion) {
      if (this.state.dragging) {
        this.setCreaseDepth(this.springTargetDepth);
        this.springVelocity = 0;
        this.springActive = false;
        this.updatePeelUniforms();
        this.emit("peelchange", {
          amount: this.state.progress,
          progress: this.state.progress,
        });
      } else {
        this.reset();
        return;
      }
    }

    if (this.springActive) {
      const stiffness = 132 + clamp(this.options.peel.stiffness, 0, 1) * 146;
      const damping = Math.sqrt(stiffness) * 1.83;
      // Integrate in small fixed steps. A single delayed 50 ms frame with the
      // old Euler step could consume nearly the whole return animation and
      // still look like an instant reset.
      let remainingSpringTime = delta;
      let nextDepth = this.creaseDepth;
      while (remainingSpringTime > 0) {
        const springStep = Math.min(remainingSpringTime, 1 / 120);
        const acceleration =
          -stiffness * (nextDepth - this.springTargetDepth) -
          damping * this.springVelocity;
        this.springVelocity += acceleration * springStep;
        nextDepth += this.springVelocity * springStep;
        remainingSpringTime -= springStep;
      }
      if (
        Math.abs(nextDepth - this.springTargetDepth) <=
          this.grabExtent * 0.0008 &&
        Math.abs(this.springVelocity) < this.grabExtent * 0.018
      ) {
        this.setCreaseDepth(this.springTargetDepth);
        this.springVelocity = 0;
        this.springActive = false;
        if (!this.state.dragging && this.springTargetDepth === 0) {
          this.state.pointer = null;
          this.state.grabPoint = null;
        }
      } else {
        this.setCreaseDepth(Math.max(0, nextDepth));
        if (!this.state.dragging) {
          this.state.pointer = {
            x: this.grabOrigin.x + this.activeDirection.x * this.grabProjection,
            y: this.grabOrigin.y + this.activeDirection.y * this.grabProjection,
          };
        }
      }
      this.updatePeelUniforms();
      this.emit("peelchange", {
        amount: this.state.progress,
        progress: this.state.progress,
      });
    }

    if (this.detachedExitActive) {
      this.detachedExitElapsed += delta;
      const exitSpeed =
        Math.max(this.viewWidth, this.viewHeight) *
        (1.45 + this.detachedExitElapsed * 3.2);
      this.stickerMesh.position.x +=
        this.activeDirection.x * exitSpeed * delta;
      this.stickerMesh.position.y +=
        this.activeDirection.y * exitSpeed * delta;
      this.stickerMesh.rotation.z += this.detachedExitSpin * delta;
      if (this.detachedExitElapsed >= 0.46) {
        this.emit("detachcomplete", { progress: 1 });
        if (this.destroyed) return;
        this.startEntranceAnimation();
        return;
      }
    }

    if (this.preparedEntrance) {
      this.preparedEntrance.elapsed += delta;
      const progress = clamp(
        this.preparedEntrance.elapsed / PRE_ENTRANCE_DURATION,
        0,
        1,
      );
      const easedProgress = smoothstep(0, 1, progress);
      this.uniforms.uPreparedMix.value = easedProgress;
      this.uniforms.uPreEntranceProgress.value = easedProgress;
      if (progress >= 1) {
        const prepared = this.preparedEntrance;
        this.preparedEntrance = null;
        this.sourceRevision += 1;
        this.requestedSource = prepared.source;
        this.source = prepared.source;
        this.options = resolveStickerOptions(this.options, {
          ...prepared.options,
          source: prepared.source,
        });
        this.applyArtwork(prepared.artwork, prepared.texture);
        this.startEntranceAnimation();
        return;
      }
    }

    if (this.entranceActive) {
      this.entranceElapsed += delta;
      if (this.applyEntranceElapsed(this.entranceElapsed)) {
        this.entranceActive = false;
        this.clearEntrancePose();
        this.emit("cyclecomplete", { progress: 0 });
      }
    }

    if (this.interactionHintActive) {
      this.interactionHintElapsed += delta;
      const hintProgress = clamp(
        this.interactionHintElapsed / INTERACTION_HINT_DURATION,
        0,
        1,
      );
      if (reducedMotion) {
        this.uniforms.uInteractionHint.value = hintProgress < 0.72 ? 1 : 0;
      } else {
        const fadeIn = smoothstep(0, 0.12, hintProgress);
        const fadeOut = 1 - smoothstep(0.58, 1, hintProgress);
        const pulse = 0.9 + Math.sin(hintProgress * Math.PI * 2) * 0.1;
        this.uniforms.uInteractionHint.value = fadeIn * fadeOut * pulse;
      }
      if (hintProgress >= 1) {
        this.interactionHintActive = false;
        this.uniforms.uInteractionHint.value = 0;
      }
    }

    if (this.backgroundRemovalEffectActive) {
      const laserSettings = getLaserEffectSettings();
      this.applyLaserEffectSettings();
      if (reducedMotion) {
        this.uniforms.uEntranceSweep.value = 0.5;
      } else {
        this.backgroundRemovalEffectElapsed += delta;
        const cycleElapsed =
          this.backgroundRemovalEffectElapsed
          % (laserSettings.cycleDuration / 1000);
        this.uniforms.uEntranceSweep.value = Math.min(
          cycleElapsed / (laserSettings.sweepDuration / 1000),
          1,
        );
      }
    }

    this.uniforms.uTime.value = time / 1000;
    this.renderer.render(this.scene, this.camera);
    const windIsAnimating =
      !reducedMotion && this.options.wind > 0.001 && this.state.progress > 0.01;
    if (
      this.springActive ||
      this.detachedExitActive ||
      this.preparedEntrance !== null ||
      this.entranceActive ||
      this.interactionHintActive ||
      (this.backgroundRemovalEffectActive && !reducedMotion) ||
      windIsAnimating
    ) {
      this.requestRender();
    }
  };

  private emit(name: string, detail: Record<string, unknown>) {
    this.container.dispatchEvent(new CustomEvent(name, { detail }));
  }
}

function copyStickerState(state: Readonly<StickerState>): StickerState {
  return {
    ready: state.ready,
    dragging: state.dragging,
    progress: state.progress,
    grabPoint: state.grabPoint ? { ...state.grabPoint } : null,
    pointer: state.pointer ? { ...state.pointer } : null,
  };
}

function copyRenderSnapshot(
  snapshot: StickerRenderSnapshot,
): StickerRenderSnapshot {
  return {
    ...snapshot,
    origin: { ...snapshot.origin },
    direction: { ...snapshot.direction },
    position: { ...snapshot.position },
    scale: { ...snapshot.scale },
  };
}

class StickerInstanceHandle implements StickerInstance {
  private renderer: StickerRenderer | null;
  private lastState: Readonly<StickerState>;
  private lastSnapshot: StickerRenderSnapshot;

  constructor(renderer: StickerRenderer) {
    this.renderer = renderer;
    this.lastState = renderer.getState();
    this.lastSnapshot = renderer.getRenderSnapshot();
  }

  async setSource(source: StickerSource): Promise<void> {
    await this.renderer?.setSource(source);
  }

  async prepareSource(
    source: StickerSource,
    options?: Partial<StickerOptions>,
  ): Promise<PreparedStickerSource> {
    if (!this.renderer) {
      throw new Error("The sticker renderer has been destroyed.");
    }
    return this.renderer.prepareSource(source, options);
  }

  setOptions(options: Partial<StickerOptions>): void {
    this.renderer?.setOptions(options);
  }

  reset(): void {
    this.renderer?.reset();
  }

  setPeelProgress(
    progress: number,
    motion?: StickerPlaybackMotion,
  ): void {
    this.renderer?.setPeelProgress(progress, motion);
  }

  setEntranceProgress(progress: number): void {
    this.renderer?.setEntranceProgress(progress);
  }

  setBackgroundRemovalEffect(active: boolean): void {
    this.renderer?.setBackgroundRemovalEffect(active);
  }

  reappear(): void {
    this.renderer?.reappear();
  }

  setRenderScale(scale: number): void {
    this.renderer?.setRenderScale(scale);
  }

  getRenderSnapshot(): StickerRenderSnapshot {
    if (this.renderer) {
      this.lastSnapshot = this.renderer.getRenderSnapshot();
      return this.lastSnapshot;
    }
    return copyRenderSnapshot(this.lastSnapshot);
  }

  setRenderSnapshot(snapshot: StickerRenderSnapshot): void {
    this.renderer?.setRenderSnapshot(snapshot);
  }

  resize = (): void => {
    this.renderer?.resize();
  };

  getState(): Readonly<StickerState> {
    if (this.renderer) {
      this.lastState = this.renderer.getState();
      return this.lastState;
    }
    return copyStickerState(this.lastState);
  }

  destroy(): void {
    const current = this.renderer;
    if (!current) return;
    this.lastState = current.getState();
    this.lastSnapshot = current.getRenderSnapshot();
    try {
      current.destroy();
    } finally {
      // The public handle can outlive destroy(), but it must not keep the
      // renderer, its detached canvas, or Three.js object graph reachable.
      this.renderer = null;
    }
  }
}

function createStickerInstanceHandle(
  renderer: StickerRenderer,
): StickerInstance {
  return new StickerInstanceHandle(renderer);
}

export async function createSticker(
  target: HTMLElement | string,
  options: StickerOptions = {},
): Promise<StickerInstance> {
  if (typeof document === "undefined") {
    throw new Error("Sticker Forge can only be created in a browser.");
  }
  const container =
    typeof target === "string" ? document.querySelector<HTMLElement>(target) : target;
  if (!container) throw new Error("Sticker Forge could not find its target element.");
  const renderer = new StickerRenderer(container, options);
  try {
    await renderer.setSource(options.source ?? DEFAULT_SOURCE);
    return createStickerInstanceHandle(renderer);
  } catch (error) {
    renderer.destroy();
    throw error;
  }
}

const HTMLElementBase =
  typeof HTMLElement === "undefined"
    ? (class {} as typeof HTMLElement)
    : HTMLElement;

export class StickerForgeElement extends HTMLElementBase {
  static get observedAttributes() {
    return ["text"];
  }

  private instance: StickerInstance | null = null;
  private instancePromise: Promise<StickerInstance> | null = null;
  private mountElement: HTMLDivElement | null = null;
  private pendingOptions: Partial<StickerOptions> = {};
  private pendingSource: StickerSource | null = null;
  private lifecycleRevision = 0;

  connectedCallback() {
    if (!this.shadowRoot) {
      const shadow = this.attachShadow({ mode: "open" });
      const style = document.createElement("style");
      style.textContent = `
        :host { display: block; min-width: 160px; min-height: 120px; }
        .mount { width: 100%; height: 100%; min-height: inherit; }
      `;
      this.mountElement = document.createElement("div");
      this.mountElement.className = "mount";
      shadow.append(style, this.mountElement);
      for (const eventName of [
        "peelstart",
        "peelchange",
        "peelend",
        "detachcomplete",
        "cyclecomplete",
        "error",
      ]) {
        this.mountElement.addEventListener(eventName, (event) => {
          this.dispatchEvent(
            new CustomEvent(eventName, {
              detail: (event as CustomEvent).detail,
              bubbles: true,
              composed: true,
            }),
          );
        });
      }
    }
    if (!this.pendingSource) {
      this.pendingSource = {
        ...DEFAULT_SOURCE,
        text: this.getAttribute("text") || DEFAULT_SOURCE.text,
      };
    }
    void this.ensureInstance().catch(() => {
      // ensureInstance already forwards a useful error event.
    });
  }

  disconnectedCallback() {
    this.destroy();
  }

  attributeChangedCallback(name: string, oldValue: string | null, value: string | null) {
    if (name === "text" && oldValue !== value) {
      const source = { ...DEFAULT_SOURCE, text: value || " " };
      this.pendingSource = source;
      if (this.isConnected) {
        void this.setSource(source).catch(() => {
          // The instance forwards the source failure as an error event.
        });
      }
    }
  }

  async setSource(source: StickerSource): Promise<void> {
    this.pendingSource = source;
    const instance = await this.ensureInstance();
    await instance.setSource(source);
  }

  async prepareSource(
    source: StickerSource,
    options?: Partial<StickerOptions>,
  ): Promise<PreparedStickerSource> {
    const instance = await this.ensureInstance();
    return instance.prepareSource(source, options);
  }

  setOptions(options: Partial<StickerOptions>): void {
    this.pendingOptions = mergePublicOptions(this.pendingOptions, options);
    this.instance?.setOptions(options);
  }

  reset(): void {
    this.instance?.reset();
  }

  setPeelProgress(
    progress: number,
    motion?: StickerPlaybackMotion,
  ): void {
    this.instance?.setPeelProgress(progress, motion);
  }

  setEntranceProgress(progress: number): void {
    this.instance?.setEntranceProgress(progress);
  }

  setBackgroundRemovalEffect(active: boolean): void {
    this.instance?.setBackgroundRemovalEffect(active);
  }

  reappear(): void {
    this.instance?.reappear();
  }

  setRenderScale(scale: number): void {
    this.instance?.setRenderScale(scale);
  }

  getRenderSnapshot(): StickerRenderSnapshot {
    return (
      this.instance?.getRenderSnapshot() ?? {
        progress: 0,
        peelDepth: 0,
        peelRadius: 0,
        detachedTension: 0,
        origin: { x: 0, y: 0 },
        direction: { x: 1, y: 0 },
        position: { x: 0, y: 0 },
        scale: { x: 1, y: 1 },
        rotation: 0,
        entranceSweep: -1,
        entranceScaleProgress: -1,
        time: 0,
      }
    );
  }

  setRenderSnapshot(snapshot: StickerRenderSnapshot): void {
    this.instance?.setRenderSnapshot(snapshot);
  }

  resize(): void {
    this.instance?.resize();
  }

  getState(): Readonly<StickerState> {
    return (
      this.instance?.getState() ?? {
        ready: false,
        dragging: false,
        progress: 0,
        grabPoint: null,
        pointer: null,
      }
    );
  }

  destroy(): void {
    this.lifecycleRevision += 1;
    const pending = this.instancePromise;
    this.instance?.destroy();
    this.instance = null;
    this.instancePromise = null;
    if (pending) {
      void pending.then((instance) => {
        instance.destroy();
      }).catch(() => {
        // A failed initialization has already emitted an error event.
      });
    }
  }

  private ensureInstance(): Promise<StickerInstance> {
    if (this.instance) return Promise.resolve(this.instance);
    if (this.instancePromise) return this.instancePromise;
    if (!this.mountElement) {
      return Promise.reject(new Error("The sticker element is not connected."));
    }
    const options = mergePublicOptions(this.pendingOptions, {
      source: this.pendingSource ?? DEFAULT_SOURCE,
    });
    const revision = this.lifecycleRevision;
    const pending = createSticker(this.mountElement, options);
    this.instancePromise = pending;
    void pending
      .then((instance) => {
        if (this.instancePromise === pending) this.instancePromise = null;
        if (revision !== this.lifecycleRevision || !this.isConnected) {
          instance.destroy();
          return;
        }
        this.instance = instance;
        this.dispatchEvent(
          new CustomEvent("ready", { bubbles: true, composed: true }),
        );
      })
      .catch((error: unknown) => {
        if (this.instancePromise === pending) this.instancePromise = null;
        const message =
          error instanceof Error
            ? error.message
            : "Sticker Forge could not initialize.";
        this.dispatchEvent(
          new CustomEvent("error", {
            detail: { message },
            bubbles: true,
            composed: true,
          }),
        );
      });
    return pending;
  }
}

export function defineStickerForge(tagName = "sticker-forge"): void {
  if (typeof customElements === "undefined") return;
  if (!customElements.get(tagName)) {
    const ElementClass =
      tagName === "sticker-forge"
        ? StickerForgeElement
        : class extends StickerForgeElement {};
    customElements.define(tagName, ElementClass);
  }
}
